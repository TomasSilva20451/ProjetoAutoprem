﻿/**
 * @file VendaVeiculoService.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Classe que representa a Vendas de Automóveis
 * @version 0.2
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */

using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    public class VendaVeiculoService
    {
        private List<Veiculo> veiculosDisponiveisParaVenda;
        private List<Venda> vendasRealizadas;

        public VendaVeiculoService()
        {
            veiculosDisponiveisParaVenda = new List<Veiculo>();
            vendasRealizadas = new List<Venda>();
        }

        public void AdicionarVeiculoParaVenda(Veiculo veiculo)
        {
            veiculosDisponiveisParaVenda.Add(veiculo);
            Console.WriteLine($"Veículo {veiculo.ID} adicionado para venda.");
        }

        public List<Veiculo> ListarVeiculosDisponiveis()
        {
            return veiculosDisponiveisParaVenda;
        }

        public void RealizarVenda(int veiculoId, Cliente cliente)
        {
            var veiculo = veiculosDisponiveisParaVenda.FirstOrDefault(v => v.ID == veiculoId);
            if (veiculo != null)
            {
                vendasRealizadas.Add(new Venda(cliente, veiculo));
                veiculosDisponiveisParaVenda.Remove(veiculo);
                Console.WriteLine($"Venda do veículo {veiculo.ID} para o cliente {cliente.Nome} realizada com sucesso.");
                // Aqui você pode integrar um sistema de faturamento ou geração de recibos.
            }
            else
            {
                Console.WriteLine("Veículo não disponível para venda.");
            }
        }

        public List<Venda> ObterRegistroVendas()
        {
            return vendasRealizadas;
        }

        // Outros métodos conforme necessário...
    }

    
}
