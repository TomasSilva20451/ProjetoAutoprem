﻿/**
 * @file ComponenteEspecifico.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Definition of the ComponenteEspecifico class, derived from Componente
 * @version 0.1
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */

public class ComponenteEspecifico : Componente
{
    #region Propriedades Adicionadas

    public bool ManutencaoRealizada { get; private set; }
    public bool SubstituicaoRealizada { get; private set; }

    #endregion

    #region Métodos Overrides

    /// <summary>
    /// Realiza a manutenção específica do componente.
    /// </summary>
    public override void RealizarManutencao()
    {
        // TODO: Implementar a lógica específica de manutenção
        // Exemplo: Colocar a lógica real aqui
        ManutencaoRealizada = true;
    }

    /// <summary>
    /// Substitui o componente específico por um novo.
    /// </summary>
    public override void Substituir()
    {
        // TODO: Implementar a lógica específica de substituição
        // Exemplo: Colocar a lógica real aqui
        SubstituicaoRealizada = true;
    }

    #endregion

    #region Outros Métodos e Propriedades

    // Adicione mais métodos e propriedades conforme necessário

    #endregion
}
