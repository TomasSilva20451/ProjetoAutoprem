﻿using System;
namespace AutoPrem.Core
{
    public class MockVeiculo : Veiculo
    {
        public MockVeiculo(int id, string modelo, string marca, int ano) : base(id, modelo, marca, ano)
        {
            // You can provide concrete initialization logic here if needed
        }

        public override bool RealizarManutencao()
        {
            // Provide a concrete implementation for testing
            return true; // Example implementation
        }

        public override bool Substituir()
        {
            // Provide a concrete implementation for testing
            return true; // Example implementation
        }
    }

}

