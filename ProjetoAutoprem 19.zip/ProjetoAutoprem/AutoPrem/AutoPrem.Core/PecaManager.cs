﻿/**
 * @file PecaManager.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe que representa o Peca Manager
 * @version 0.1
 * @date 2023-12-30
 * @remarks ADOÇÃO ADEQUADA DAS NORMAS CLS; DOCUMENTAÇÃO ADEQUADA DO CÓDIGO; ESTRUTURA DE PASTAS, NOMES E TIPOS DOS PROJETOS, NOMES DE MÉTODOS E CLASSES, NOME DO FICHEIRO A SUBMETER
 */

using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    public class PecaManager
    {
        #region Propriedades
        private List<Componente> pecas;
        #endregion

        #region Construtores
        public PecaManager()
        {
            pecas = new List<Componente>();
        }
        #endregion

        #region Métodos

        // Método para adicionar uma peça
        public void AdicionarPeca(Componente peca)
        {
            pecas.Add(peca);
            Console.WriteLine("Peça adicionada com sucesso.");
        }

        // Método para listar todas as peças
        public List<Componente> ListarPecas()
        {
            return pecas;
        }

        // Método para obter uma peça por ID
        public Componente? ObterPecaPorId(int id)
        {
            return pecas.FirstOrDefault(p => p.Id == id);
        }

        // Método para atualizar uma peça por ID
        public void AtualizarPeca(int id, Componente pecaAtualizada)
        {
            var peca = ObterPecaPorId(id);
            if (peca != null)
            {
                // Atualize as propriedades da peça conforme necessário
                // Exemplo: peca.Nome = pecaAtualizada.Nome;
                Console.WriteLine("Peça atualizada com sucesso.");
            }
            else
            {
                Console.WriteLine("Peça não encontrada.");
            }
        }

        // Método para remover uma peça por ID
        public void RemoverPeca(int id)
        {
            var peca = ObterPecaPorId(id);
            if (peca != null)
            {
                pecas.Remove(peca);
                Console.WriteLine("Peça removida com sucesso.");
            }
            else
            {
                Console.WriteLine("Peça não encontrada.");
            }
        }

        #endregion
    }
}
