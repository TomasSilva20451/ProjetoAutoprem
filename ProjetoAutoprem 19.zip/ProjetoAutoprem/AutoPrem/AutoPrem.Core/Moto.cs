﻿/**
 * @file Moto.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Definition of the Moto class, derived from Veiculo
 * @version 0.2
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */
using System;

public class Moto : Veiculo
{
    public Moto(int id) : base(id, "ModeloDaMoto", "MarcaDaMoto", 2024)
    {
        // Initialize Moto-specific attributes in the constructor, if necessary
    }

    public override bool RealizarManutencao()
    {
        // Implement the maintenance logic specific to Moto here
        // Return true if maintenance was successful, otherwise return false
        bool maintenanceSuccessful = true; // Replace with your actual logic
        return maintenanceSuccessful;
    }

    public override bool Substituir()
    {
        // Implement the substitution logic specific to Moto here
        // Return true if substitution was successful, otherwise return false
        bool substitutionSuccessful = true; // Replace with your actual logic
        return substitutionSuccessful;
    }

    public override bool Ligar()
    {
        base.Ligar();
        return true;
    }

    public override bool Desligar()
    {
        base.Desligar();
        return true;
    }

    public bool RealizarManutencaoMoto()
    {
        var condicaoMoto = VerificarCondicaoMoto();

        if (condicaoMoto)
        {
            return true;
        }

        var servicosManutencao = SelecionarServicosManutencao(condicaoMoto);

        foreach (var servico in servicosManutencao)
        {
            servico.Executar();
        }

        this.DataManutencao = DateTime.Now;

        foreach (var servico in servicosManutencao)
        {
            // Console.WriteLine messages are not included here.
        }

        return true;
    }

    protected override bool VerificarCondicaoMoto()
    {
        // Return true as an example
        return true;
    }

    // Other methods and properties can be added here as needed
}
