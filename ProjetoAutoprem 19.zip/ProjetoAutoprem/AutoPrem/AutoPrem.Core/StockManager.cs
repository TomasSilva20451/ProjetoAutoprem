﻿/**
 * @file StockManager.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe que representa o Stock Manager
 * @version 0.2
 * @date 2023-12-30
 * @remarks ADOÇÃO ADEQUADA DAS NORMAS CLS; DOCUMENTAÇÃO ADEQUADA DO CÓDIGO; ESTRUTURA DE PASTAS, NOMES E TIPOS DOS PROJETOS, NOMES DE MÉTODOS E CLASSES, NOME DO FICHEIRO A SUBMETER
 */

using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    public class StockManager
    {
        #region Propriedades
        private List<Componente> componentes;
        #endregion

        #region Construtores
        public StockManager()
        {
            componentes = new List<Componente>();
        }
        #endregion

        #region Métodos

        public void AdicionarComponente(Componente componente)
        {
            componentes.Add(componente);
            Console.WriteLine("Componente adicionado ao estoque.");
        }

        public void AtualizarComponente(int id, string novaDescricao)
        {
            var componente = componentes.FirstOrDefault(c => c.Id == id);
            if (componente != null)
            {
                componente.Descricao = novaDescricao;
                Console.WriteLine("Componente atualizado com sucesso.");
            }
            else
            {
                Console.WriteLine("Componente não encontrado.");
            }
        }

        public void RemoverComponente(int id)
        {
            var componente = componentes.FirstOrDefault(c => c.Id == id);
            if (componente != null)
            {
                componentes.Remove(componente);
                Console.WriteLine("Componente removido com sucesso.");
            }
            else
            {
                Console.WriteLine("Componente não encontrado.");
            }
        }

        public List<Componente> ListarComponentes()
        {
            return componentes;
        }

        #endregion
    }
}
