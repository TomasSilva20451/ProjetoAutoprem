﻿using AutoPrem.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;

[TestClass]
public class FuncionarioManagerTests
{
    [TestMethod]
    public void AdicionarFuncionario_DeveAdicionarFuncionario()
    {
        // Arrange
        var funcionarioManager = new FuncionarioManager();
        var funcionario = new Funcionario("João", "joao@email.com", "123456789");

        // Act
        funcionarioManager.AdicionarFuncionario(funcionario);

        // Assert
        var funcionarios = funcionarioManager.ListarFuncionarios();
        Assert.IsTrue(funcionarios.Contains(funcionario));
    }

    [TestMethod]
    public void AtualizarFuncionario_FuncionarioExistente_DeveAtualizar()
    {
        // Arrange
        var funcionarioManager = new FuncionarioManager();
        var funcionario = new Funcionario("João", "joao@email.com", "123456789");
        funcionarioManager.AdicionarFuncionario(funcionario);

        // Act
        funcionarioManager.AtualizarFuncionario(funcionario.Id, "NovoNome", "novo@email.com", "987654321");

        // Assert
        var funcionarioAtualizado = funcionarioManager.ObterFuncionarioPorId(funcionario.Id);
        Assert.IsNotNull(funcionarioAtualizado); // Verifique se o funcionário atualizado não é nulo
        if (funcionarioAtualizado != null)
        {
            // Acesse as propriedades após a verificação de nulidade
            Assert.AreEqual("NovoNome", funcionarioAtualizado.Nome);
            Assert.AreEqual("novo@email.com", funcionarioAtualizado.Email);
            Assert.AreEqual("987654321", funcionarioAtualizado.NumeroTelefone);
        }
    }


    [TestMethod]
    public void RemoverFuncionario_FuncionarioExistente_DeveRemover()
    {
        // Arrange
        var funcionarioManager = new FuncionarioManager();
        var funcionario = new Funcionario("João", "joao@email.com", "123456789");
        funcionarioManager.AdicionarFuncionario(funcionario);

        // Act
        funcionarioManager.RemoverFuncionario(funcionario.Id);

        // Assert
        var funcionarios = funcionarioManager.ListarFuncionarios();
        Assert.IsFalse(funcionarios.Contains(funcionario));
    }
}
