﻿using System;

namespace AutoPrem.Core
{
    public class Cliente
    {
        public string? Nome { get; set; }
        public string? Email { get; set; }
        public string? NumeroTelefone { get; set; }
        public string? DetalhesPagamento { get; set; }

        // Adicione mais informações conforme necessário

        // Default constructor
        public Cliente()
        {
        }

        // Constructor that accepts nome and email
        public Cliente(string nome, string email)
        {
            Nome = nome;
            Email = email;
        }
    }
}
