﻿/**
 * @file FuncionarioTests.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Testes para a classe Funcionario
 * @version 0.1
 * @date 2023-12-18
 * @copyright Copyright (c) 2023
 */

using Microsoft.VisualStudio.TestTools.UnitTesting;
using AutoPrem.Core;

[TestClass]
public class FuncionarioTests
{
    #region Atributos

    // Declaração de atributos de teste aqui (se necessário)

    #endregion
    #region Métodos de Teste

    [TestMethod]
    public void RealizarTarefa_TarefaBemSucedida_RetornaTrue()
    {
        // Arrange
        Funcionario funcionario = new Funcionario("João", "joao@email.com", "123456789");
        ComponenteEspecifico componente = new ComponenteEspecifico();

        // Act
        bool resultado = funcionario.RealizarTarefa(componente);

        // Assert
        Assert.IsTrue(resultado);
    }

    [TestMethod]
    public void RealizarTarefa_TarefaFalhada_RetornaFalse()
    {
        // Arrange
        Funcionario funcionario = new Funcionario("Maria", "maria@email.com", "987654321");
        ComponenteEspecifico componente = new ComponenteEspecifico();
        // Forçar falha na tarefa definindo um componente em um estado específico
        componente.RealizarManutencao(); // Simulando falha

        // Act
        bool resultado = funcionario.RealizarTarefa(componente);

        // Assert
        Assert.IsFalse(resultado);
    }

    // Adicione mais testes conforme necessário

    #endregion
}