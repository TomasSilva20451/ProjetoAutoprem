﻿/**
 * @file Program.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Ponto de entrada principal para a aplicação
 * @version 0.2
 * @date 2023-12-18
 * @remarks ADOÇÃO ADEQUADA DAS NORMAS CLS; DOCUMENTAÇÃO ADEQUADA DO CÓDIGO; ESTRUTURA DE PASTAS, NOMES E TIPOS DOS PROJETOS, NOMES DE MÉTODOS E CLASSES, NOME DO FICHEIRO A SUBMETER
 * @copyright Copyright (c) 2023
 */

using System;
using AutoPrem.Core;
using AutoPrem.Core.Services;

class Program
{
    private readonly IIOService ioService;

    public Program(IIOService ioService)
    {
        this.ioService = ioService;
    }

    static void Main()
    {
        Program program = new Program(new ConsoleIOService());
        program.Run();
    }

    public void Run()
    {
        ExemploUtilizacao();
        ExemploServicosTarefas();
    }

    #region ExemploUtilizacao
    private void ExemploUtilizacao()
    {
        Carro carro = new Carro(1);
        Moto moto = new Moto(2);
        carro.Ligar();
        carro.Desligar();
        moto.Ligar();
        moto.Desligar();
    }
    #endregion

    #region LidarComVeiculoException
    private void LidarComVeiculoException(Action action, string sucessoMessage)
    {
        try
        {
            action.Invoke();
            ioService.WriteLine(sucessoMessage);
        }
        catch (Exception ex)
        {
            ioService.WriteLine($"Erro: {ex.Message}");
        }
    }
    #endregion

    #region ExemploServicosTarefas
    private void ExemploServicosTarefas()
    {
        try
        {
            Carro carro = new Carro(1);
            ServicoManutencao servico = new ServicoManutencao(DateTime.Now, "Manutenção de rotina", carro);
            servico.RealizarManutencao(carro);
            ioService.WriteLine("Manutenção realizada com sucesso.");
        }
        catch (Exception ex)
        {
            ioService.WriteLine($"Erro ao realizar manutenção: {ex.Message}");
        }

        try
        {
            Componente componente = new ComponenteEspecifico();
            ServicoManutencao servico = new ServicoManutencao(DateTime.Now, "Manutenção de rotina", componente);
            servico.RealizarManutencao(componente);
            ioService.WriteLine("Manutenção realizada com sucesso.");
        }
        catch (Exception ex)
        {
            ioService.WriteLine($"Erro ao realizar manutenção: {ex.Message}");
        }

        try
        {
            Funcionario funcionario = new Funcionario("João", "joao@email.com", "123456789");
            bool sucessoTarefa = funcionario.RealizarTarefa(new ComponenteEspecifico());
            ioService.WriteLine(sucessoTarefa ? "Tarefa realizada com sucesso." : "Erro ao realizar tarefa.");
        }
        catch (Exception ex)
        {
            ioService.WriteLine($"Erro ao realizar tarefa: {ex.Message}");
        }
    }
    #endregion
}

