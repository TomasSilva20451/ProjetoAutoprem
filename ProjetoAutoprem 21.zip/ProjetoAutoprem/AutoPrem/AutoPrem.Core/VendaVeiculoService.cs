﻿/**
 * @file VendaVeiculoService.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe responsável pelo gerenciamento e realização de vendas de veículos.
 * @version 0.1
 * @date 2023-12-17
 * @copyright Copyright (c) 2023
 */

using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    public class VendaVeiculoService
    {
        #region Propriedades
        private List<Veiculo> veiculosDisponiveisParaVenda;
        private List<Venda> vendasRealizadas;
        #endregion

        #region Construtores
        public VendaVeiculoService()
        {
            veiculosDisponiveisParaVenda = new List<Veiculo>();
            vendasRealizadas = new List<Venda>();
        }
        #endregion

        #region Métodos

        /// <summary>
        /// Adiciona um veículo à lista de veículos disponíveis para venda.
        /// </summary>
        /// <param name="veiculo">Veículo a ser adicionado.</param>
        /// <returns>True se o veículo for adicionado com sucesso.</returns>
        public bool AdicionarVeiculoParaVenda(Veiculo veiculo)
        {
            veiculosDisponiveisParaVenda.Add(veiculo);
            return true; // Veículo adicionado para venda com sucesso
        }

        /// <summary>
        /// Lista todos os veículos disponíveis para venda.
        /// </summary>
        /// <returns>Lista de veículos disponíveis.</returns>
        public List<Veiculo> ListarVeiculosDisponiveis()
        {
            return veiculosDisponiveisParaVenda;
        }

        /// <summary>
        /// Realiza a venda de um veículo para um cliente.
        /// </summary>
        /// <param name="veiculoId">ID do veículo a ser vendido.</param>
        /// <param name="cliente">Cliente que está comprando o veículo.</param>
        /// <returns>True se a venda for realizada com sucesso, false se o veículo não estiver disponível.</returns>
        public bool RealizarVenda(int veiculoId, Cliente cliente)
        {
            var veiculo = veiculosDisponiveisParaVenda.FirstOrDefault(v => v.ID == veiculoId);
            if (veiculo != null)
            {
                vendasRealizadas.Add(new Venda(cliente, veiculo));
                veiculosDisponiveisParaVenda.Remove(veiculo);
                return true; // Venda realizada com sucesso
            }
            else
            {
                return false; // Veículo não disponível para venda
            }
        }

        /// <summary>
        /// Obtém o registro de todas as vendas realizadas.
        /// </summary>
        /// <returns>Lista de vendas realizadas.</returns>
        public List<Venda> ObterRegistoVendas()
        {
            return vendasRealizadas;
        }

        // Outros métodos conforme necessário...

        #endregion
    }
}
