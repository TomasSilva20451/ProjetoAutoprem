﻿/**
 * @file PecaManager.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe gerenciadora para operações relacionadas a peças/componentes
 * @version 0.1
 * @date 2023-12-17
 * @copyright Copyright (c) 2023
 */

using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    /// <summary>
    /// Gerencia as operações relacionadas a peças/componentes, como adicionar, atualizar e remover.
    /// </summary>
    public class PecaManager
    {
        #region Propriedades
        private List<Componente> pecas;
        #endregion

        #region Construtores
        /// <summary>
        /// Construtor padrão que inicializa a lista de peças/componentes.
        /// </summary>
        public PecaManager()
        {
            pecas = new List<Componente>();
        }
        #endregion

        #region Métodos

        /// <summary>
        /// Adiciona uma nova peça à lista.
        /// </summary>
        /// <param name="peca">Peça a ser adicionada.</param>
        /// <returns>True se a peça for adicionada com sucesso, false em caso de falha.</returns>
        public bool AdicionarPeca(Componente peca)
        {
            try
            {
                pecas.Add(peca);
                return true; // Peça adicionada com sucesso
            }
            catch (Exception)
            {
                return false; // Falha ao adicionar a peça
            }
        }

        /// <summary>
        /// Lista todas as peças.
        /// </summary>
        /// <returns>Lista de peças/componentes.</returns>
        public List<Componente> ListarPecas()
        {
            return pecas;
        }

        /// <summary>
        /// Obtém uma peça pelo seu ID.
        /// </summary>
        /// <param name="id">ID da peça.</param>
        /// <returns>A peça, se encontrada; null, caso contrário.</returns>
        public Componente? ObterPecaPorId(int id)
        {
            return pecas.FirstOrDefault(p => p.Id == id);
        }

        /// <summary>
        /// Atualiza as informações de uma peça existente.
        /// </summary>
        /// <param name="id">ID da peça a ser atualizada.</param>
        /// <param name="pecaAtualizada">Peça com as informações atualizadas.</param>
        /// <returns>True se a peça for atualizada com sucesso, false se não for encontrada.</returns>
        public bool AtualizarPeca(int id, Componente pecaAtualizada)
        {
            var peca = ObterPecaPorId(id);
            if (peca != null)
            {
                // Atualiza as propriedades da peça aqui
                return true; // Peça atualizada com sucesso
            }
            return false; // Peça não encontrada
        }

        /// <summary>
        /// Remove uma peça da lista pelo ID.
        /// </summary>
        /// <param name="id">ID da peça a ser removida.</param>
        /// <returns>True se a peça for removida com sucesso, false se não for encontrada.</returns>
        public bool RemoverPeca(int id)
        {
            var peca = ObterPecaPorId(id);
            if (peca != null)
            {
                pecas.Remove(peca);
                return true; // Peça removida com sucesso
            }
            return false; // Peça não encontrada
        }

        #endregion
    }
}
