﻿/**
 * @file FuncionarioManager.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe gerenciadora para operações relacionadas a funcionários
 * @version 0.1
 * @date 2023-12-17
 * @copyright Copyright (c) 2023
 */

using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    /// <summary>
    /// Gerencia as operações relacionadas a funcionários, como adicionar, atualizar e remover.
    /// </summary>
    public class FuncionarioManager
    {
        #region Propriedades
        private List<Funcionario> funcionarios;
        #endregion

        #region Construtores
        /// <summary>
        /// Construtor padrão que inicializa a lista de funcionários.
        /// </summary>
        public FuncionarioManager()
        {
            funcionarios = new List<Funcionario>();
        }
        #endregion

        #region Métodos

        /// <summary>
        /// Adiciona um novo funcionário à lista.
        /// </summary>
        /// <param name="funcionario">Funcionário a ser adicionado.</param>
        /// <returns>True se o funcionário for adicionado com sucesso, false em caso de falha.</returns>
        public bool AdicionarFuncionario(Funcionario funcionario)
        {
            try
            {
                funcionarios.Add(funcionario);
                return true; // Adicionado com sucesso
            }
            catch (Exception)
            {
                return false; // Falha ao adicionar
            }
        }

        /// <summary>
        /// Atualiza as informações de um funcionário existente.
        /// </summary>
        /// <param name="id">ID do funcionário a ser atualizado.</param>
        /// <param name="novoNome">Novo nome do funcionário.</param>
        /// <param name="novoEmail">Novo email do funcionário.</param>
        /// <param name="novoNumeroTelefone">Novo número de telefone do funcionário.</param>
        /// <returns>True se o funcionário for atualizado com sucesso, false se não for encontrado.</returns>
        public bool AtualizarFuncionario(int id, string novoNome, string novoEmail, string novoNumeroTelefone)
        {
            var funcionario = funcionarios.FirstOrDefault(f => f.Id == id);
            if (funcionario != null)
            {
                funcionario.Nome = novoNome;
                funcionario.Email = novoEmail;
                funcionario.NumeroTelefone = novoNumeroTelefone;
                return true; // Atualizado com sucesso
            }
            return false; // Não encontrado
        }

        /// <summary>
        /// Remove um funcionário da lista.
        /// </summary>
        /// <param name="id">ID do funcionário a ser removido.</param>
        /// <returns>True se o funcionário for removido com sucesso, false se não for encontrado.</returns>
        public bool RemoverFuncionario(int id)
        {
            var funcionario = funcionarios.FirstOrDefault(f => f.Id == id);
            if (funcionario != null)
            {
                funcionarios.Remove(funcionario);
                return true; // Removido com sucesso
            }
            return false; // Não encontrado
        }

        /// <summary>
        /// Lista todos os funcionários.
        /// </summary>
        /// <returns>Lista de funcionários.</returns>
        public List<Funcionario> ListarFuncionarios()
        {
            return funcionarios;
        }

        /// <summary>
        /// Cria um novo funcionário e o adiciona à lista.
        /// </summary>
        /// <param name="nome">Nome do novo funcionário.</param>
        /// <param name="email">Email do novo funcionário.</param>
        /// <param name="numeroTelefone">Número de telefone do novo funcionário.</param>
        /// <returns>True se o funcionário for criado e adicionado com sucesso, false em caso de falha.</returns>
        public bool CriarNovoFuncionario(string nome, string email, string numeroTelefone)
        {
            try
            {
                Funcionario novoFuncionario = new Funcionario(nome, email, numeroTelefone);
                funcionarios.Add(novoFuncionario);
                return true; // Criado e adicionado com sucesso
            }
            catch (Exception)
            {
                return false; // Falha ao criar
            }
        }

        /// <summary>
        /// Obtém um funcionário pelo seu ID.
        /// </summary>
        /// <param name="id">ID do funcionário.</param>
        /// <returns>O funcionário, se encontrado; null, caso contrário.</returns>
        public Funcionario? ObterFuncionarioPorId(int id)
        {
            return funcionarios.FirstOrDefault(f => f.Id == id);
        }

        /// <summary>
        /// Atualiza as informações de um funcionário.
        /// </summary>
        /// <param name="id">ID do funcionário.</param>
        /// <param name="novoNome">Novo nome do funcionário.</param>
        /// <param name="novoEmail">Novo email do funcionário.</param>
        /// <param name="novoNumeroTelefone">Novo número de telefone do funcionário.</param>
        /// <returns>True se as informações forem atualizadas com sucesso, false se o funcionário não for encontrado.</returns>
        public bool AtualizarInformacoesDoFuncionario(int id, string novoNome, string novoEmail, string novoNumeroTelefone)
        {
            var funcionario = ObterFuncionarioPorId(id);
            if (funcionario != null)
            {
                funcionario.Nome = novoNome;
                funcionario.Email = novoEmail;
                funcionario.NumeroTelefone = novoNumeroTelefone;
                return true; // Informações atualizadas com sucesso
            }
            return false; // Não encontrado
        }

        #endregion
    }
}
