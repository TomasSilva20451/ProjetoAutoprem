﻿/**
 * @file ComponenteEspecifico.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Definition of the ComponenteEspecifico class, derived from Componente
 * @version 0.1
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */

/// <summary>
/// Classe que representa um componente específico, derivada da classe abstrata Componente.
/// </summary>
public class ComponenteEspecifico : Componente
{
    #region Propriedades 

    /// <summary>
    /// Indica se a manutenção foi realizada com sucesso.
    /// </summary>
    public bool ManutencaoRealizada { get; private set; }

    /// <summary>
    /// Indica se a substituição do componente foi realizada com sucesso.
    /// </summary>
    public bool SubstituicaoRealizada { get; private set; }

    // Outras propriedades relacionadas a diferentes operações realizadas no componente.
    public bool LimparRealizada { get; private set; }
    public bool LubrificarRealizada { get; private set; }
    public bool RemoverRealizada { get; private set; }
    public bool InstalarRealizada { get; private set; }
    #endregion

    #region Métodos Overrides

    /// <summary>
    /// Realiza a manutenção específica do componente.
    /// Este método verifica primeiro se o componente está danificado e, se estiver, tenta substituí-lo.
    /// Caso o componente não esteja danificado, realiza operações de limpeza e lubrificação.
    /// </summary>
    /// <returns>Retorna true se a manutenção for bem-sucedida, caso contrário, false.</returns>
    public override bool RealizarManutencao()
    {
        if (EstaDanificado)
        {
            if (Substituir())
            {
                ManutencaoRealizada = true;
                return true;
            }
            return false;
        }
        else
        {
            if (Limpar() && Lubrificar())
            {
                ManutencaoRealizada = true;
                return true;
            }
            return false;
        }
    }

    /// <summary>
    /// Substitui o componente específico por um novo.
    /// Este método primeiro remove o componente antigo e, em seguida, tenta instalar um novo.
    /// </summary>
    /// <returns>Retorna true se a substituição for bem-sucedida, caso contrário, false.</returns>
    public override bool Substituir()
    {
        if (Remover())
        {
            if (Instalar())
            {
                SubstituicaoRealizada = true;
                return true;
            }
        }
        return false;
    }

    #endregion

    #region Métodos Privados

    // Métodos privados para realizar operações específicas, como limpar e lubrificar.
    // Esses métodos são chamados no processo de manutenção.

    private bool Limpar()
    {
        LimparRealizada = true;
        return true;
    }

    private bool Lubrificar()
    {
        LubrificarRealizada = true;
        return true;
    }

    private bool Remover()
    {
        EstaDanificado = true;
        return true;
    }

    private bool Instalar()
    {
        if (!RemoverRealizada)
        {
            throw new Exception("O componente antigo deve ser removido antes de instalar o novo.");
        }

        InstalarRealizada = true;
        return true;
    }

    #endregion

    #region Outros Métodos e Propriedades

    // Adicione mais métodos e propriedades conforme necessário

    #endregion
}
