﻿/**
 * @file CompraService.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe de serviço para gerenciar compras de veículos e componentes
 * @version 0.1
 * @date 2023-12-17
 * @copyright Copyright (c) 2023
 */

using System;
using System.Collections.Generic;

namespace AutoPrem.Core.Services
{
    /// <summary>
    /// Classe de serviço para gerenciar compras de veículos e componentes.
    /// </summary>
    public class CompraService
    {
        #region Propriedades
        // Catálogos de veículos e componentes
        private List<Veiculo> catalogoVeiculos;
        private List<Componente> catalogoComponentes;
        #endregion

        #region Construtores
        /// <summary>
        /// Construtor para inicializar os catálogos de veículos e componentes.
        /// </summary>
        public CompraService()
        {
            catalogoVeiculos = new List<Veiculo>();
            catalogoComponentes = new List<Componente>();
        }
        #endregion

        #region Outros Métodos

        /// <summary>
        /// Visualizar o catálogo de veículos.
        /// </summary>
        /// <returns>Lista de veículos no catálogo.</returns>
        public List<Veiculo> VisualizarCatalogoVeiculos()
        {
            return catalogoVeiculos;
        }

        /// <summary>
        /// Visualizar o catálogo de componentes.
        /// </summary>
        /// <returns>Lista de componentes no catálogo.</returns>
        public List<Componente> VisualizarCatalogoComponentes()
        {
            return catalogoComponentes;
        }

        /// <summary>
        /// Realizar um pedido de veículo.
        /// </summary>
        /// <param name="veiculoId">ID do veículo a ser pedido.</param>
        /// <param name="quantidade">Quantidade do veículo a ser pedido.</param>
        /// <returns>True se o pedido for bem-sucedido, false caso contrário.</returns>
        public bool FazerPedidoVeiculo(int veiculoId, int quantidade)
        {
            if (VeiculoExisteNoCatalogo(veiculoId) && QuantidadeValida(quantidade))
            {
                // Implementação do pedido de veículo
                return true; // Retorna verdadeiro se o pedido for bem-sucedido
            }
            return false; // Retorna falso se falhar
        }

        /// <summary>
        /// Realizar um pedido de componente.
        /// </summary>
        /// <param name="componenteId">ID do componente a ser pedido.</param>
        /// <param name="quantidade">Quantidade do componente a ser pedido.</param>
        /// <returns>True se o pedido for bem-sucedido, false caso contrário.</returns>
        public bool FazerPedidoComponente(int componenteId, int quantidade)
        {
            if (ComponenteExisteNoCatalogo(componenteId) && QuantidadeValida(quantidade))
            {
                // Implementação do pedido de componente
                return true; // Retorna verdadeiro se o pedido for bem-sucedido
            }
            return false; // Retorna falso se falhar
        }

        /// <summary>
        /// Processar o pagamento de um pedido.
        /// </summary>
        /// <param name="valorTotal">Valor total a ser pago.</param>
        /// <returns>True se o pagamento for bem-sucedido, false caso contrário.</returns>
        public bool ProcessarPagamento(decimal valorTotal)
        {
            if (PagamentoBemSucedido(valorTotal))
            {
                // Implementação do processamento do pagamento
                return true; // Retorna verdadeiro se o pagamento for bem-sucedido
            }
            return false; // Retorna falso se falhar
        }

        // Métodos privados para validar dados de entrada e simular operações
        #region Métodos de Validação Privados

        private bool VeiculoExisteNoCatalogo(int veiculoId)
        {
            // Implementação da validação
            return true; // Exemplo
        }

        private bool ComponenteExisteNoCatalogo(int componenteId)
        {
            // Implementação da validação
            return true; // Exemplo
        }

        private bool QuantidadeValida(int quantidade)
        {
            return quantidade > 0;
        }

        private bool PagamentoBemSucedido(decimal valorTotal)
        {
            // Implementação da simulação de sucesso/falha do pagamento
            return true; // Exemplo
        }

        #endregion

        #endregion
    }
}
