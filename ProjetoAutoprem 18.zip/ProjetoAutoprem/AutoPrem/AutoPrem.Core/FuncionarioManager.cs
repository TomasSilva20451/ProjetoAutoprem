﻿/**
 * @file FuncionarioManager.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe que representa o Funcionario Manager
 * @version 0.2
 * @date 2023-12-12
 * @remarks ADOÇÃO ADEQUADA DAS NORMAS CLS; DOCUMENTAÇÃO ADEQUADA DO CÓDIGO; ESTRUTURA DE PASTAS, NOMES E TIPOS DOS PROJETOS, NOMES DE MÉTODOS E CLASSES, NOME DO FICHEIRO A SUBMETER
 */

using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    public class FuncionarioManager
    {
        #region Propriedades
        private List<Funcionario> funcionarios;
        #endregion

        #region Construtores
        public FuncionarioManager()
        {
            funcionarios = new List<Funcionario>();
        }
        #endregion

        #region Métodos

        public void AdicionarFuncionario(Funcionario funcionario)
        {
            funcionarios.Add(funcionario);
            Console.WriteLine("Funcionário adicionado com sucesso.");
        }

        public void AtualizarFuncionario(int id, string novoNome, string novoEmail, string novoNumeroTelefone)
        {
            var funcionario = funcionarios.FirstOrDefault(f => f.Id == id);
            if (funcionario != null)
            {
                funcionario.Nome = novoNome;
                funcionario.Email = novoEmail;
                funcionario.NumeroTelefone = novoNumeroTelefone;
                Console.WriteLine("Funcionário atualizado com sucesso.");
            }
            else
            {
                Console.WriteLine("Funcionário não encontrado.");
            }
        }

        public void RemoverFuncionario(int id)
        {
            var funcionario = funcionarios.FirstOrDefault(f => f.Id == id);
            if (funcionario != null)
            {
                funcionarios.Remove(funcionario);
                Console.WriteLine("Funcionário removido com sucesso.");
            }
            else
            {
                Console.WriteLine("Funcionário não encontrado.");
            }
        }

        public List<Funcionario> ListarFuncionarios()
        {
            return funcionarios;
        }

        public void CriarNovoFuncionario(string nome, string email, string numeroTelefone)
        {
            // Crie um novo objeto Funcionario com os dados fornecidos
            Funcionario novoFuncionario = new Funcionario(nome, email, numeroTelefone);

            // Adicione o novo funcionário à lista de funcionários
            funcionarios.Add(novoFuncionario);
        }

        public Funcionario? ObterFuncionarioPorId(int id)
        {
            return funcionarios.FirstOrDefault(f => f.Id == id);
        }

        public void AtualizarInformacoesDoFuncionario(int id, string novoNome, string novoEmail, string novoNumeroTelefone)
        {
            var funcionario = ObterFuncionarioPorId(id);
            if (funcionario != null)
            {
                // Atualize as informações do funcionário
                funcionario.Nome = novoNome;
                funcionario.Email = novoEmail;
                funcionario.NumeroTelefone = novoNumeroTelefone;
            }
            else
            {
                // Funcionário não encontrado, você pode lidar com isso de acordo com sua lógica
            }
        }

        #endregion
    }
}
