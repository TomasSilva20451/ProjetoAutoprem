﻿/**
 * @file VeiculoTests.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Testes para a classe Veiculo
 * @version 0.1
 * @date 2023-12-18
 * @copyright Copyright (c) 2023
 */

using Microsoft.VisualStudio.TestTools.UnitTesting;
using AutoPrem.Core;

[TestClass]
public class VeiculoTests
{
    #region Atributos

    // Declaração de atributos de teste aqui (se necessário)

    #endregion

    #region Métodos de Teste

    [TestMethod]
    public void TestLigarVeiculo_AlteraStatusManutencao()
    {
        // Arrange
        Veiculo veiculo = new Carro(1);

        // Act
        veiculo.Ligar();

        // Assert
        Assert.IsTrue(veiculo.EstaEmManutencao);
    }

    #endregion
}