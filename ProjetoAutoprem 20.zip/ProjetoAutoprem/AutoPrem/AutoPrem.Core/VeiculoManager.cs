﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    public class VeiculoManager
    {
        #region Propriedades
        private List<Veiculo> veiculos;
        #endregion

        #region Construtores
        public VeiculoManager()
        {
            veiculos = new List<Veiculo>();
        }
        #endregion

        #region Métodos

        public bool AdicionarVeiculo(Veiculo veiculo)
        {
            veiculos.Add(veiculo);
            return true; // Veículo adicionado com sucesso
        }

        public bool AtualizarVeiculo(int id, Veiculo veiculoAtualizado)
        {
            var veiculo = ObterVeiculoPorId(id);
            // Agora temos certeza de que veiculo não é nulo
            // Atualize as propriedades do veículo conforme necessário
            veiculo.Modelo = veiculoAtualizado.Modelo;
            veiculo.Marca = veiculoAtualizado.Marca;
            // Outras propriedades...
            return true; // Veículo atualizado com sucesso
        }

        public bool RemoverVeiculo(int id)
        {
            var veiculo = ObterVeiculoPorId(id);
            // Agora temos certeza de que veiculo não é nulo
            veiculos.Remove(veiculo);
            return true; // Veículo removido com sucesso
        }

        public List<Veiculo> ListarVeiculos()
        {
            return veiculos;
        }

        public Veiculo ObterVeiculoPorId(int id)
        {
            var veiculo = veiculos.FirstOrDefault(v => v.ID == id);
            if (veiculo == null)
            {
                throw new ArgumentException("Veículo não encontrado.");
            }
            return veiculo;
        }

        #endregion
    }
}
