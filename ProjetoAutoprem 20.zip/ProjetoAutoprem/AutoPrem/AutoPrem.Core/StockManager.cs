﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    public class StockManager
    {
        #region Propriedades
        private List<Componente> componentes;
        #endregion

        #region Construtores
        public StockManager()
        {
            componentes = new List<Componente>();
        }
        #endregion

        #region Métodos

        public bool AdicionarComponente(Componente componente)
        {
            componentes.Add(componente);
            return true; // Componente adicionado ao estoque com sucesso
        }

        public bool AtualizarComponente(int id, string novaDescricao)
        {
            var componente = componentes.FirstOrDefault(c => c.Id == id);
            if (componente != null)
            {
                componente.Descricao = novaDescricao;
                return true; // Componente atualizado com sucesso
            }
            else
            {
                return false; // Componente não encontrado
            }
        }

        public bool RemoverComponente(int id)
        {
            var componente = componentes.FirstOrDefault(c => c.Id == id);
            if (componente != null)
            {
                componentes.Remove(componente);
                return true; // Componente removido com sucesso
            }
            else
            {
                return false; // Componente não encontrado
            }
        }

        public List<Componente> ListarComponentes()
        {
            return componentes;
        }

        #endregion
    }
}
