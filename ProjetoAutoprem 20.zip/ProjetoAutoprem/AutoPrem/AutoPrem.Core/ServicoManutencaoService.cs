﻿using System;

namespace AutoPrem.Core.Services
{
    /// <summary>
    /// Serviço responsável por agendar e realizar manutenções.
    /// </summary>
    public class ServicoManutencaoService
    {
        #region Atributos e Construtores
        private ServicoManutencao _servicoManutencao;

        /// <summary>
        /// Construtor da classe ServicoManutencaoService.
        /// </summary>
        /// <param name="servicoManutencao">Instância de ServicoManutencao associada ao serviço.</param>
        public ServicoManutencaoService(ServicoManutencao servicoManutencao)
        {
            _servicoManutencao = servicoManutencao;
        }
        #endregion

        #region Métodos

        /// <summary>
        /// Agenda uma manutenção se ainda não foi realizada.
        /// </summary>
        /// <returns>True se a manutenção foi agendada com sucesso; False se já foi realizada anteriormente ou o componente não é um veículo.</returns>
        public bool AgendarManutencao()
        {
            if (!_servicoManutencao.Realizado)
            {
                // Assuming Veiculo is a subtype of Componente
                if (_servicoManutencao.Componente is Veiculo veiculo)
                {
                    _servicoManutencao.Agendamento = new AgendamentoManutencao();
                    _servicoManutencao.Agendamento.DataAgendamento = _servicoManutencao.DataAgendamento;
                    _servicoManutencao.Agendamento.Descricao = _servicoManutencao.Descricao;

                    _servicoManutencao.Realizado = true;

                    return true; // Manutenção agendada com sucesso
                }
                else
                {
                    return false; // Componente não é um veículo
                }
            }
            else
            {
                return false; // Manutenção já realizada anteriormente
            }
        }

        /// <summary>
        /// Realiza a manutenção utilizando um veículo e um cliente específico.
        /// </summary>
        /// <param name="veiculo">Veículo a ser mantido.</param>
        /// <param name="cliente">Cliente associado à manutenção.</param>
        /// <returns>True se a manutenção foi realizada com sucesso; False se o veículo já estiver em manutenção.</returns>
        public bool RealizarManutencao(Veiculo veiculo, Cliente cliente)
        {
            if (!veiculo.EstaEmManutencao)
            {
                var servico = new ServicoManutencao(DateTime.Now, "Manutenção de rotina", veiculo);
                servico.AgendarManutencao(cliente);
                return true; // Manutenção realizada com sucesso
            }
            else
            {
                return false; // Veículo já está em manutenção
            }
        }

        #endregion
    }
}
