﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    public class PecaManager
    {
        #region Propriedades
        private List<Componente> pecas;
        #endregion

        #region Construtores
        public PecaManager()
        {
            pecas = new List<Componente>();
        }
        #endregion

        #region Métodos

        // Método para adicionar uma peça
        public bool AdicionarPeca(Componente peca)
        {
            try
            {
                pecas.Add(peca);
                return true; // Peça adicionada com sucesso
            }
            catch (Exception)
            {
                return false; // Falha ao adicionar peça
            }
        }

        // Método para listar todas as peças
        public List<Componente> ListarPecas()
        {
            return pecas;
        }

        // Método para obter uma peça por ID
        public Componente? ObterPecaPorId(int id)
        {
            return pecas.FirstOrDefault(p => p.Id == id);
        }

        // Método para atualizar uma peça por ID
        public bool AtualizarPeca(int id, Componente pecaAtualizada)
        {
            var peca = ObterPecaPorId(id);
            if (peca != null)
            {
                // Atualize as propriedades da peça conforme necessário
                // Exemplo: peca.Nome = pecaAtualizada.Nome;
                return true; // Peça atualizada com sucesso
            }
            return false; // Peça não encontrada
        }

        // Método para remover uma peça por ID
        public bool RemoverPeca(int id)
        {
            var peca = ObterPecaPorId(id);
            if (peca != null)
            {
                pecas.Remove(peca);
                return true; // Peça removida com sucesso
            }
            return false; // Peça não encontrada
        }

        #endregion
    }
}
