﻿/**
 * @file Veiculo.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Definition of the Veiculo class
 * @version 0.2
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */
using System;
using System.Collections.Generic;

public abstract class Veiculo : Componente
{
    public int ID { get; }
    public string Modelo { get; set; }
    public string Marca { get; set; }
    public int Ano { get; set; }
    public bool EstaEmManutencao { get; private set; }
    public DateTime DataManutencao { get; set; }

    public Veiculo(int id, string modelo, string marca, int ano)
    {
        ID = id;
        Modelo = modelo;
        Marca = marca;
        Ano = ano;
        EstaEmManutencao = false;
    }

    public abstract override bool RealizarManutencao();
    public abstract override bool Substituir();

    public void SetManutencaoStatus(bool status)
    {
        EstaEmManutencao = status;
    }

    protected virtual bool VerificarCondicaoVeiculo()
    {
        // Implement logic to check the vehicle's condition
        // For example, check if there is a specific problem with the vehicle
        return true; // or false, depending on the actual logic
    }

    public virtual bool Ligar()
    {
        // Implement logic to start the vehicle.
        return true; // For example, always return true for now
    }

    public virtual bool Desligar()
    {
        // Implement logic to turn off the vehicle.
        return true; // For example, always return true for now
    }

    protected virtual List<ServicoManutencao> SelecionarServicosManutencao(bool condicaoCarro)
    {
        // Return an empty list for now
        return new List<ServicoManutencao>();
    }

    protected virtual bool VerificarCondicaoCarro()
    {
        // Just return true for now
        return true;
    }

    protected virtual bool VerificarCondicaoMoto()
    {
        // Just return true for now
        return true;
    }
}
