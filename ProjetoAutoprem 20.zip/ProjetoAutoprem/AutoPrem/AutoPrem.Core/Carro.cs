﻿/**
 * @file Carro.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Definition of the Carro class, derived from Veiculo
 * @version 0.3
 * @date 2023-12-23
 * @copyright Copyright (c) 2023
 */
using System;
using System.Collections.Generic;

public class Carro : Veiculo
{
    public Carro(int id) : base(id, "ModeloDoCarro", "MarcaDoCarro", 2024)
    {
        this.DataManutencao = DateTime.Now;
    }

    public override bool RealizarManutencao()
    {
        // Implement the maintenance logic specific to Carro here
        // Return true if maintenance was successful, otherwise return false
        bool maintenanceSuccessful = true; // Replace with your actual logic
        return maintenanceSuccessful;
    }

    public override bool Substituir()
    {
        // Implement the substitution logic specific to Carro here
        // Return true if substitution was successful, otherwise return false
        bool substitutionSuccessful = true; // Replace with your actual logic
        return substitutionSuccessful;
    }

    public override bool Ligar()
    {
        base.Ligar();
        return true;
    }

    public override bool Desligar()
    {
        base.Desligar();
        return true;
    }

    public bool RealizarManutencaoCarro()
    {
        var condicaoCarro = VerificarCondicaoCarro();

        if (condicaoCarro)
        {
            return true;
        }

        var servicosManutencao = SelecionarServicosManutencao(condicaoCarro);

        foreach (var servico in servicosManutencao)
        {
            servico.Executar();
        }

        this.DataManutencao = DateTime.Now;

        foreach (var servico in servicosManutencao)
        {
            // Console.WriteLine messages are not included here.
        }

        return true;
    }

    // Other methods and properties can be added here as needed
}
