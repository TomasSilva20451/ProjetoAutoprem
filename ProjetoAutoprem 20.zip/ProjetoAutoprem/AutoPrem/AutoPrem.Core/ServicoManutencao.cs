﻿/**
 * @file ServicoManutencao.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Definition of the ServicoManutencao class
 * @version 0.2
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */

using System;
using AutoPrem.Core;

public class ServicoManutencao
{
    #region Propriedades

    /// <summary>
    /// Data de agendamento do serviço de manutenção.
    /// </summary>
    public DateTime DataAgendamento { get; }

    /// <summary>
    /// Nome do serviço de manutenção.
    /// </summary>
    public string? Nome { get; set; }

    /// <summary>
    /// Descrição do serviço de manutenção.
    /// </summary>
    public string Descricao { get; private set; }

    /// <summary>
    /// Indica se o serviço de manutenção foi realizado.
    /// </summary>
    public bool Realizado { get; set; }

    /// <summary>
    /// Classe Componente
    /// </summary>
    public Componente Componente { get; set; }

    /// <summary>
    /// Classe AgendamentoManutencao
    /// </summary>
    public AgendamentoManutencao? Agendamento { get; set; }

    /// <summary>
    /// Classe Cliente
    /// </summary>
    public Cliente? Cliente { get; set; }

    #endregion

    #region Construtores

    /// <summary>
    /// Construtor da classe ServicoManutencao.
    /// </summary>
    public ServicoManutencao(DateTime dataAgendamento, string descricao, Componente componente)
    {
        DataAgendamento = dataAgendamento;
        Descricao = descricao;
        Componente = componente;
        Realizado = false;
    }


    #endregion

    #region Métodos

    /// <summary>
    /// Realiza a manutenção utilizando um componente específico.
    /// </summary>
    /// <param name="componente">Componente a ser mantido.</param>
    public void RealizarManutencao(Componente componente)
    {
        if (this.Componente is Veiculo veiculo && !veiculo.EstaEmManutencao)
        {
            Console.WriteLine($"Realizando manutenção no veículo com ID {veiculo.ID}.");
            veiculo.SetManutencaoStatus(true);
            Realizado = true;
        }
        else
        {
            Console.WriteLine("Manutenção não realizada: componente não é veículo ou já está em manutenção.");
        }
    }


    public void AgendarManutencao(Cliente cliente)
    {
        if (Realizado)
        {
            Console.WriteLine($"O serviço de manutenção já foi realizado em {DataAgendamento.ToShortDateString()}: {Descricao}");
        }
        else
        {
            Console.WriteLine($"Agendando serviço de manutenção para {DataAgendamento.ToShortDateString()}: {Descricao}");
            Cliente = cliente;
            Realizado = true;
        }
    }


   

    public AgendamentoManutencao AgendarManutencao()
    {
        AgendamentoManutencao agendamento = new AgendamentoManutencao();
        agendamento.DataAgendamento = DataAgendamento;
        agendamento.Descricao = Descricao;
        agendamento.Componente = Componente;
        Agendamento = agendamento;
        Console.WriteLine($"Agendando serviço de manutenção para {agendamento.DataAgendamento.ToShortDateString()}: {agendamento.Descricao}");
        Realizado = true;
        return agendamento;
    }

    public void Executar()
    {

        Console.WriteLine($"Executando serviço de manutenção: {Nome}");
    }

    #endregion
}