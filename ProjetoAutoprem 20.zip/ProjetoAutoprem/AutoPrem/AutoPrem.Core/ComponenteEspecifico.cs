﻿/**
 * @file ComponenteEspecifico.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Definition of the ComponenteEspecifico class, derived from Componente
 * @version 0.1
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */

public class ComponenteEspecifico : Componente
{
    #region Propriedades 

    public bool ManutencaoRealizada { get; private set; }
    public bool SubstituicaoRealizada { get; private set; }
    public bool LimparRealizada { get; private set; }
    public bool LubrificarRealizada { get; private set; }
    public bool RemoverRealizada { get; private set; }
    public bool InstalarRealizada { get; private set; }
    #endregion

    #region Métodos Overrides

    /// <summary>
    /// Realiza a manutenção específica do componente.
    /// </summary>
    /// <returns>Retorna true se a manutenção foi realizada com sucesso, false caso contrário.</returns>
    public override bool RealizarManutencao()
    {
        // Verifica se o componente está danificado
        if (EstaDanificado)
        {
            // Substitui o componente por um novo
            if (Substituir())
            {
                ManutencaoRealizada = true;
                return true;
            }
            return false;
        }
        else
        {
            // Limpa e lubrifica o componente
            if (Limpar() && Lubrificar())
            {
                ManutencaoRealizada = true;
                return true;
            }
            return false;
        }
    }

    /// <summary>
    /// Substitui o componente específico por um novo.
    /// </summary>
    /// <returns>Retorna true se a substituição foi realizada com sucesso, false caso contrário.</returns>
    public override bool Substituir()
    {
        // Remove o componente antigo
        if (Remover())
        {
            // Instala o componente novo
            if (Instalar())
            {
                SubstituicaoRealizada = true;
                return true;
            }
        }
        return false;
    }

    #endregion

    #region Métodos Privados

    private bool Limpar()
    {
        // Podemos definir a propriedade "LimparRealizada" como true para simular a remoção
        LimparRealizada = true;
        return true;
    }

    private bool Lubrificar()
    {
        // Podemos definir a propriedade "LubrificarRealizada" como true para simular a remoção
        LubrificarRealizada = true;
        return true;
    }

    private bool Remover()
    {
        // Podemos definir a propriedade "EstaDanificado" como true para simular a remoção
        EstaDanificado = true;
        return true;
    }

    private bool Instalar()
    {
        // Verifique se o componente antigo foi removido
        if (!RemoverRealizada)
        {
            throw new Exception("O componente antigo deve ser removido antes de instalar o novo.");
        }

        InstalarRealizada = true;
        return true;
    }

    #endregion

    #region Outros Métodos e Propriedades

    // Adicione mais métodos e propriedades conforme necessário

    #endregion
}
