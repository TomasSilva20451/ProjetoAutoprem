﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    public class FuncionarioManager
    {
        #region Propriedades
        private List<Funcionario> funcionarios;
        #endregion

        #region Construtores
        public FuncionarioManager()
        {
            funcionarios = new List<Funcionario>();
        }
        #endregion

        #region Métodos

        public bool AdicionarFuncionario(Funcionario funcionario)
        {
            try
            {
                funcionarios.Add(funcionario);
                return true; // Funcionário adicionado com sucesso
            }
            catch (Exception)
            {
                return false; // Falha ao adicionar funcionário
            }
        }

        public bool AtualizarFuncionario(int id, string novoNome, string novoEmail, string novoNumeroTelefone)
        {
            var funcionario = funcionarios.FirstOrDefault(f => f.Id == id);
            if (funcionario != null)
            {
                funcionario.Nome = novoNome;
                funcionario.Email = novoEmail;
                funcionario.NumeroTelefone = novoNumeroTelefone;
                return true; // Funcionário atualizado com sucesso
            }
            return false; // Funcionário não encontrado
        }

        public bool RemoverFuncionario(int id)
        {
            var funcionario = funcionarios.FirstOrDefault(f => f.Id == id);
            if (funcionario != null)
            {
                funcionarios.Remove(funcionario);
                return true; // Funcionário removido com sucesso
            }
            return false; // Funcionário não encontrado
        }

        public List<Funcionario> ListarFuncionarios()
        {
            return funcionarios;
        }

        public bool CriarNovoFuncionario(string nome, string email, string numeroTelefone)
        {
            try
            {
                // Crie um novo objeto Funcionario com os dados fornecidos
                Funcionario novoFuncionario = new Funcionario(nome, email, numeroTelefone);

                // Adicione o novo funcionário à lista de funcionários
                funcionarios.Add(novoFuncionario);
                return true; // Funcionário criado com sucesso
            }
            catch (Exception)
            {
                return false; // Falha ao criar funcionário
            }
        }

        public Funcionario? ObterFuncionarioPorId(int id)
        {
            return funcionarios.FirstOrDefault(f => f.Id == id);
        }

        public bool AtualizarInformacoesDoFuncionario(int id, string novoNome, string novoEmail, string novoNumeroTelefone)
        {
            var funcionario = ObterFuncionarioPorId(id);
            if (funcionario != null)
            {
                // Atualize as informações do funcionário
                funcionario.Nome = novoNome;
                funcionario.Email = novoEmail;
                funcionario.NumeroTelefone = novoNumeroTelefone;
                return true; // Informações do funcionário atualizadas com sucesso
            }
            return false; // Funcionário não encontrado
        }

        #endregion
    }
}
