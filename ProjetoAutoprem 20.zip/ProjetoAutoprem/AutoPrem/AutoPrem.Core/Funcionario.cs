﻿public class Funcionario
{
    #region Propriedades

    /// <summary>
    /// Identificador único 
    /// </summary>
    public int Id { get; set; }
    public string Nome { get; set; }
    public string Email { get; set; }
    public string NumeroTelefone { get; set; }

    #endregion

    #region Construtores

    /// <summary>
    /// Construtor da classe Funcionario.
    /// </summary>
    /// <param name="nome">Nome do funcionário.</param>
    /// <param name="email">Email do funcionário.</param>
    /// <param name="numeroTelefone">Número de telefone do funcionário.</param>
    public Funcionario(string nome, string email, string numeroTelefone)
    {
        Nome = nome;
        Email = email;
        NumeroTelefone = numeroTelefone;
    }

    #endregion

    #region Métodos

    /// <summary>
    /// Realiza uma tarefa utilizando o componente.
    /// </summary>
    /// <param name="componente">Componente a ser utilizado na tarefa.</param>
    /// <returns>True se a tarefa foi realizada com sucesso; false, caso contrário.</returns>
    public bool RealizarTarefa(Componente componente)
    {
        // Verifica se o componente está danificado
        if (componente.EstaDanificado)
        {
            // Realiza a substituição do componente
            componente.Substituir();
            return true; // Tarefa realizada com sucesso após a substituição do componente
        }

        // O componente não está danificado, então a tarefa foi realizada com sucesso
        return true;
    }

    // Adicione mais métodos e propriedades conforme necessário

    #endregion
}
