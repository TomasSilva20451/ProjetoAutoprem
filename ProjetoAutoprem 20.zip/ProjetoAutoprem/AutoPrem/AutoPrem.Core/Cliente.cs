﻿/**
 * @file Cliente.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe que representa um cliente
 * @version 0.1
 * @date 2023-12-30
 * @remarks ADOÇÃO ADEQUADA DAS NORMAS CLS; DOCUMENTAÇÃO ADEQUADA DO CÓDIGO; ESTRUTURA DE PASTAS, NOMES E TIPOS DOS PROJETOS, NOMES DE MÉTODOS E CLASSES, NOME DO FICHEIRO A SUBMETER
 */

using System;

namespace AutoPrem.Core
{
    public class Cliente
    {
        #region Propriedades
        public string? Nome { get; set; }
        public string? Email { get; set; }
        public string? NumeroTelefone { get; set; }
        public string? DetalhesPagamento { get; set; }
        #endregion

        #region Construtores
        // Default constructor
        public Cliente()
        {
        }

        // Constructor that accepts nome and email
        public Cliente(string nome, string email)
        {
            Nome = nome;
            Email = email;
        }
        #endregion

        #region Outros Métodos
        // Adicione mais informações conforme necessário
        #endregion
    }
}
