﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    public class VendaVeiculoService
    {
        #region Propriedades
        private List<Veiculo> veiculosDisponiveisParaVenda;
        private List<Venda> vendasRealizadas;
        #endregion

        #region Construtores
        public VendaVeiculoService()
        {
            veiculosDisponiveisParaVenda = new List<Veiculo>();
            vendasRealizadas = new List<Venda>();
        }
        #endregion

        #region Métodos

        public bool AdicionarVeiculoParaVenda(Veiculo veiculo)
        {
            veiculosDisponiveisParaVenda.Add(veiculo);
            return true; // Veículo adicionado para venda com sucesso
        }

        public List<Veiculo> ListarVeiculosDisponiveis()
        {
            return veiculosDisponiveisParaVenda;
        }

        public bool RealizarVenda(int veiculoId, Cliente cliente)
        {
            var veiculo = veiculosDisponiveisParaVenda.FirstOrDefault(v => v.ID == veiculoId);
            if (veiculo != null)
            {
                vendasRealizadas.Add(new Venda(cliente, veiculo));
                veiculosDisponiveisParaVenda.Remove(veiculo);
                // Aqui você pode integrar um sistema de faturamento ou geração de recibos.
                return true; // Venda realizada com sucesso
            }
            else
            {
                return false; // Veículo não disponível para venda
            }
        }

        public List<Venda> ObterRegistroVendas()
        {
            return vendasRealizadas;
        }

        // Outros métodos conforme necessário...

        #endregion
    }
}
