﻿/**
 * @file ComponenteTests.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Testes para a classe Componente
 * @version 0.1
 * @date 2023-12-18
 * @copyright Copyright (c) 2023
 */

using Microsoft.VisualStudio.TestTools.UnitTesting;
using AutoPrem.Core;

[TestClass]
public class ComponenteTests
{
    #region Métodos de Teste

    [TestMethod]
    public void RealizarManutencao_ComponenteGenerico_LogicaDeManutencaoGenerico()
    {
        // Arrange
        Componente componente = new ComponenteGenerico();

        // Act
        componente.RealizarManutencao();

        // Assert
        Assert.IsTrue(((ComponenteGenerico)componente).ManutencaoRealizada);
    }

    [TestMethod]
    public void Substituir_ComponenteGenerico_LogicaDeSubstituicaoGenerico()
    {
        // Arrange
        Componente componente = new ComponenteGenerico();

        // Act
        componente.Substituir();

        // Assert
        Assert.IsTrue(((ComponenteGenerico)componente).SubstituicaoRealizada);
    }

    #endregion

    #region Classe de Teste Interna

    private class ComponenteGenerico : Componente
    {
        public bool ManutencaoRealizada { get; private set; }
        public bool SubstituicaoRealizada { get; private set; }

        public override void RealizarManutencao()
        {
            // Lógica de manutenção genérica
            ManutencaoRealizada = true;
        }

        public override void Substituir()
        {
            // Lógica de substituição genérica
            SubstituicaoRealizada = true;
        }
    }

    #endregion
}