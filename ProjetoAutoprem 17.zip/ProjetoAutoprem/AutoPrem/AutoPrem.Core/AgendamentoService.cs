﻿/**
 * @file AgendamentoService.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe que representa um agendamento service
 * @version 0.1
 * @date 2023-12-30
 * @remarks ADOÇÃO ADEQUADA DAS NORMAS CLS; DOCUMENTAÇÃO ADEQUADA DO CÓDIGO; ESTRUTURA DE PASTAS, NOMES E TIPOS DOS PROJETOS, NOMES DE MÉTODOS E CLASSES, NOME DO FICHEIRO A SUBMETER
 */

using System;
namespace AutoPrem.Core
{
    public class AgendamentoService
    {
        #region Propriedades
        private List<AgendamentoManutencao> agendamentos;
        private int nextId = 1;

        #endregion

        #region Construtores
        public AgendamentoService()
        {
            agendamentos = new List<AgendamentoManutencao>();
        }
        #endregion

        #region Métodos

        public void AgendarManutencao(DateTime data, Veiculo veiculo, string descricao)
        {
            var agendamento = new AgendamentoManutencao
            {
                Id = nextId++,
                DataAgendamento = data,
                Veiculo = veiculo,
                Descricao = descricao
            };
            agendamentos.Add(agendamento);
            Console.WriteLine("Agendamento realizado com sucesso.");
        }

        public void AtualizarAgendamento(int id, DateTime novaData, string novaDescricao)
        {
            var agendamento = agendamentos.FirstOrDefault(a => a.Id == id);
            if (agendamento != null)
            {
                agendamento.DataAgendamento = novaData;
                agendamento.Descricao = novaDescricao;
                Console.WriteLine("Agendamento atualizado com sucesso.");
            }
            else
            {
                Console.WriteLine("Agendamento não encontrado.");
            }
        }

        public void CancelarAgendamento(int id)
        {
            var agendamento = agendamentos.FirstOrDefault(a => a.Id == id);
            if (agendamento != null)
            {
                agendamentos.Remove(agendamento);
                Console.WriteLine("Agendamento cancelado com sucesso.");
            }
            else
            {
                Console.WriteLine("Agendamento não encontrado.");
            }
        }

        public List<AgendamentoManutencao> ObterAgendamentos()
        {
            return agendamentos;
        }

        #endregion
    }
}
