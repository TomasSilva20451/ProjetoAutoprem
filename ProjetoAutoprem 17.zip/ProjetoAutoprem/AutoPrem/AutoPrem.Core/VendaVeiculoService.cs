﻿/**
 * @file VendaVeiculoService.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe que representa a Venda de Automóveis
 * @version 0.2
 * @date 2023-12-30
 * @remarks ADOÇÃO ADEQUADA DAS NORMAS CLS; DOCUMENTAÇÃO ADEQUADA DO CÓDIGO; ESTRUTURA DE PASTAS, NOMES E TIPOS DOS PROJETOS, NOMES DE MÉTODOS E CLASSES, NOME DO FICHEIRO A SUBMETER
 */

using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    public class VendaVeiculoService
    {
        #region Propriedades
        private List<Veiculo> veiculosDisponiveisParaVenda;
        private List<Venda> vendasRealizadas;
        #endregion

        #region Construtores
        public VendaVeiculoService()
        {
            veiculosDisponiveisParaVenda = new List<Veiculo>();
            vendasRealizadas = new List<Venda>();
        }
        #endregion

        #region Métodos

        public void AdicionarVeiculoParaVenda(Veiculo veiculo)
        {
            veiculosDisponiveisParaVenda.Add(veiculo);
            Console.WriteLine($"Veículo {veiculo.ID} adicionado para venda.");
        }

        public List<Veiculo> ListarVeiculosDisponiveis()
        {
            return veiculosDisponiveisParaVenda;
        }

        public void RealizarVenda(int veiculoId, Cliente cliente)
        {
            var veiculo = veiculosDisponiveisParaVenda.FirstOrDefault(v => v.ID == veiculoId);
            if (veiculo != null)
            {
                vendasRealizadas.Add(new Venda(cliente, veiculo));
                veiculosDisponiveisParaVenda.Remove(veiculo);
                Console.WriteLine($"Venda do veículo {veiculo.ID} para o cliente {cliente.Nome} realizada com sucesso.");
                // Aqui você pode integrar um sistema de faturamento ou geração de recibos.
            }
            else
            {
                Console.WriteLine("Veículo não disponível para venda.");
            }
        }

        public List<Venda> ObterRegistroVendas()
        {
            return vendasRealizadas;
        }

        // Outros métodos conforme necessário...

        #endregion
    }
}
