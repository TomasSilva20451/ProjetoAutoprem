﻿/**
 * @file CompraService.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe que representa o serviço de compra
 * @version 0.1
 * @date 2023-12-30
 * @remarks ADOÇÃO ADEQUADA DAS NORMAS CLS; DOCUMENTAÇÃO ADEQUADA DO CÓDIGO; ESTRUTURA DE PASTAS, NOMES E TIPOS DOS PROJETOS, NOMES DE MÉTODOS E CLASSES, NOME DO FICHEIRO A SUBMETER
 */

using System;
using System.Collections.Generic;

namespace AutoPrem.Core.Services
{
    public class CompraService
    {
        #region Propriedades
        // Catálogos de veículos e componentes (você pode substituir com suas próprias classes de catálogo)
        private List<Veiculo> catalogoVeiculos;
        private List<Componente> catalogoComponentes;
        #endregion

        #region Construtores
        public CompraService()
        {
            // Inicialize os catálogos com dados (substitua com sua própria lógica)
            catalogoVeiculos = new List<Veiculo>();
            catalogoComponentes = new List<Componente>();
        }
        #endregion

        #region Outros Métodos
        // Visualizar catálogo de veículos
        public List<Veiculo> VisualizarCatalogoVeiculos()
        {
            return catalogoVeiculos;
        }

        // Visualizar catálogo de componentes
        public List<Componente> VisualizarCatalogoComponentes()
        {
            return catalogoComponentes;
        }

        // Realizar um pedido de veículo
        public void FazerPedidoVeiculo(int veiculoId, int quantidade)
        {
            // Verifique se o veículo está no catálogo e se a quantidade é válida
            // Implemente a lógica de pedido de veículo aqui
            Console.WriteLine($"Pedido de {quantidade} veículo(s) com ID {veiculoId} realizado com sucesso.");
        }

        // Realizar um pedido de componente
        public void FazerPedidoComponente(int componenteId, int quantidade)
        {
            // Verifique se o componente está no catálogo e se a quantidade é válida
            // Implemente a lógica de pedido de componente aqui
            Console.WriteLine($"Pedido de {quantidade} componente(s) com ID {componenteId} realizado com sucesso.");
        }

        // Processar pagamento
        public void ProcessarPagamento(decimal valorTotal)
        {
            // Implemente a lógica de processamento de pagamento aqui
            Console.WriteLine($"Pagamento de {valorTotal:C} processado com sucesso.");
        }
        #endregion
    }
}
