﻿/**
 * @file VeiculoManager.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe que representa o Veiculo Manager
 * @version 0.1
 * @date 2023-12-30
 * @remarks ADOÇÃO ADEQUADA DAS NORMAS CLS; DOCUMENTAÇÃO ADEQUADA DO CÓDIGO; ESTRUTURA DE PASTAS, NOMES E TIPOS DOS PROJETOS, NOMES DE MÉTODOS E CLASSES, NOME DO FICHEIRO A SUBMETER
 */

using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    public class VeiculoManager
    {
        #region Propriedades
        private List<Veiculo> veiculos;
        #endregion

        #region Construtores
        public VeiculoManager()
        {
            veiculos = new List<Veiculo>();
        }
        #endregion

        #region Métodos

        public void AdicionarVeiculo(Veiculo veiculo)
        {
            veiculos.Add(veiculo);
            Console.WriteLine("Veículo adicionado com sucesso.");
        }

        public Veiculo ObterVeiculoPorId(int id)
        {
            return veiculos.FirstOrDefault(v => v.ID == id) ?? throw new ArgumentException("Veículo não encontrado.");
        }

        public List<Veiculo> ListarVeiculos()
        {
            return veiculos;
        }

        public void AtualizarVeiculo(int id, Veiculo veiculoAtualizado)
        {
            var veiculo = ObterVeiculoPorId(id);
            // Agora temos certeza de que veiculo não é nulo
            // Atualize as propriedades do veículo conforme necessário
            veiculo.Modelo = veiculoAtualizado.Modelo;
            veiculo.Marca = veiculoAtualizado.Marca;
            // Outras propriedades...
            Console.WriteLine("Veículo atualizado com sucesso.");
        }

        public void RemoverVeiculo(int id)
        {
            var veiculo = ObterVeiculoPorId(id);
            // Agora temos certeza de que veiculo não é nulo
            veiculos.Remove(veiculo);
            Console.WriteLine("Veículo removido com sucesso.");
        }

        #endregion
    }
}
