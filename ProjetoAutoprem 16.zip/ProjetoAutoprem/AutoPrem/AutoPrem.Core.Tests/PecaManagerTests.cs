﻿using AutoPrem.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

[TestClass]
public class PecaManagerTests
{
    [TestMethod]
    public void AdicionarPeca_DeveAdicionarPeca()
    {
        // Arrange
        var pecaManager = new PecaManager();
        var peca = new ComponenteEspecifico(); // Use a classe derivada ComponenteEspecifico

        // Act
        pecaManager.AdicionarPeca(peca);

        // Assert
        var pecas = pecaManager.ListarPecas();
        Assert.IsTrue(pecas.Contains(peca));
    }

    [TestMethod]
    public void AtualizarPeca_PecaExistente_DeveAtualizar()
    {
        // Arrange
        var pecaManager = new PecaManager();
        var peca = new ComponenteEspecifico();
        pecaManager.AdicionarPeca(peca);

        // Act
        var pecaAtualizada = new ComponenteEspecifico();
        pecaManager.AtualizarPeca(peca.Id, pecaAtualizada);

        // Assert
        var pecaAtualizadaNoManager = pecaManager.ObterPecaPorId(peca.Id);
        Assert.IsNotNull(pecaAtualizadaNoManager);
        if (pecaAtualizadaNoManager != null)
        {
            Assert.AreEqual(peca.Id, pecaAtualizadaNoManager.Id);
            // Você pode comparar outras propriedades conforme necessário
        }
    }

    [TestMethod]
    public void RemoverPeca_PecaExistente_DeveRemover()
    {
        // Arrange
        var pecaManager = new PecaManager();
        var peca = new ComponenteEspecifico();
        pecaManager.AdicionarPeca(peca);

        // Act
        pecaManager.RemoverPeca(peca.Id);

        // Assert
        var pecas = pecaManager.ListarPecas();
        Assert.IsFalse(pecas.Contains(peca));
    }
}
