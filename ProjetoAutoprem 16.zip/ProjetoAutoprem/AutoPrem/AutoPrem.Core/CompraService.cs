﻿using System;
using System.Collections.Generic;

namespace AutoPrem.Core.Services
{
    public class CompraService
    {
        // Catálogos de veículos e componentes (você pode substituir com suas próprias classes de catálogo)
        private List<Veiculo> catalogoVeiculos;
        private List<Componente> catalogoComponentes;

        public CompraService()
        {
            // Inicialize os catálogos com dados (substitua com sua própria lógica)
            catalogoVeiculos = new List<Veiculo>();
            catalogoComponentes = new List<Componente>();
        }

        // Visualizar catálogo de veículos
        public List<Veiculo> VisualizarCatalogoVeiculos()
        {
            return catalogoVeiculos;
        }

        // Visualizar catálogo de componentes
        public List<Componente> VisualizarCatalogoComponentes()
        {
            return catalogoComponentes;
        }

        // Realizar um pedido de veículo
        public void FazerPedidoVeiculo(int veiculoId, int quantidade)
        {
            // Verifique se o veículo está no catálogo e se a quantidade é válida
            // Implemente a lógica de pedido de veículo aqui
            Console.WriteLine($"Pedido de {quantidade} veículo(s) com ID {veiculoId} realizado com sucesso.");
        }

        // Realizar um pedido de componente
        public void FazerPedidoComponente(int componenteId, int quantidade)
        {
            // Verifique se o componente está no catálogo e se a quantidade é válida
            // Implemente a lógica de pedido de componente aqui
            Console.WriteLine($"Pedido de {quantidade} componente(s) com ID {componenteId} realizado com sucesso.");
        }

        // Processar pagamento
        public void ProcessarPagamento(decimal valorTotal)
        {
            // Implemente a lógica de processamento de pagamento aqui
            Console.WriteLine($"Pagamento de {valorTotal:C} processado com sucesso.");
        }
    }
}
