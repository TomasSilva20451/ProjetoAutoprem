﻿/**
 * @file Venda.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Classe Venda de Veiculo
 * @version 0.2
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */

using System;
namespace AutoPrem.Core
{
    public class Venda
    {
        public Cliente Cliente { get; private set; }
        public Veiculo Veiculo { get; private set; }
        public DateTime DataVenda { get; private set; }

        public Venda(Cliente cliente, Veiculo veiculo)
        {
            Cliente = cliente;
            Veiculo = veiculo;
            DataVenda = DateTime.Now;
        }

        // Outros detalhes da venda...
    }
}

