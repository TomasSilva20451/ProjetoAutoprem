﻿/**
 * @file Carro.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Definition of the Carro class, derived from Veiculo
 * @version 0.3
 * @date 2023-12-23
 * @copyright Copyright (c) 2023
 */

using System;
using System.Collections.Generic; // Adicione esta diretiva para List<T>

public class Carro : Veiculo
{
    #region Construtores

    public Carro(int id) : base(id)
    {
        // TODO: Inicializar atributos específicos de Carro no construtor

        this.DataManutencao = DateTime.Now;
    }

    #endregion

    #region Overrides de Veiculo

    public override void Ligar()
    {
        base.Ligar();
        Console.WriteLine($"O carro {ID} está ligado.");
    }

    public override void Desligar()
    {
        base.Desligar();
        Console.WriteLine($"O carro {ID} está desligado.");
    }

    #endregion

    #region Métodos Específicos de Carro

    public bool RealizarManutencaoCarro()
    {
        // Verifica a condição do carro.
        var condicaoCarro = VerificarCondicaoCarro();

        // Se o carro estiver em boas condições, não é necessário realizar manutenção.
        if (condicaoCarro)
        {
            return true;
        }

        // Seleciona os serviços de manutenção necessários.
        var servicosManutencao = SelecionarServicosManutencao(condicaoCarro);

        // Executa os serviços de manutenção.
        foreach (var servico in servicosManutencao)
        {
            servico.Executar();
        }

        // Marca o carro como reparado.
        this.DataManutencao = DateTime.Now;

        // Exibe um resumo dos serviços de manutenção realizados.
        foreach (var servico in servicosManutencao)
        {
            Console.WriteLine($"Serviço de manutenção: {servico.Nome}, Descrição: {servico.Descricao}.");
        }

        return true;
    }

    #endregion

    #region Outros Métodos

    // TODO: Adicione mais métodos e propriedades conforme necessário

    #endregion

    #region Métodos Auxiliares

    private bool VerificarCondicaoPintura()
    {
        
        // Retorne true se estiver em boas condições, false caso contrário
        return true; // Exemplo: sempre retorna true por enquanto
    }

    private bool VerificarCondicaoPneus()
    {
        
        // Retorne true se estiverem em boas condições, false caso contrário
        return true; // Exemplo: sempre retorna true por enquanto
    }

    private bool VerificarCondicaoFreios()
    {
        
        // Retorne true se estiverem em boas condições, false caso contrário
        return true; // Exemplo: sempre retorna true por enquanto
    }

    private bool VerificarCondicaoSuspensão()
    {
        
        // Retorne true se estiver em boas condições, false caso contrário
        return true; // Exemplo: sempre retorna true por enquanto
    }

    protected override bool VerificarCondicaoCarro()
    {
        
        // Vamos apenas retornar true 
        return true;
    }

    protected override List<ServicoManutencao> SelecionarServicosManutencao(bool condicaoCarro)
    {
        
        // Vamos retornar uma lista vazia 
        return new List<ServicoManutencao>();
    }



    #endregion
}
