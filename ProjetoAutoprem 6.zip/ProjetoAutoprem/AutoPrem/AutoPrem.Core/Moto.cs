﻿/**
 * @file Moto.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Definition of the Moto class, derived from Veiculo
 * @version 0.2
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */

using System;

public class Moto : Veiculo
{
    #region Construtores

    /// <summary>
    /// Construtor da classe Moto.
    /// </summary>
    /// <param name="id">Identificador da moto.</param>
    public Moto(int id) : base(id)
    {
        // TODO: Inicializar atributos específicos de Moto no construtor
    }

    #endregion

    #region Métodos

    /// <summary>
    /// Liga a moto.
    /// </summary>
    public override void Ligar()
    {
        base.Ligar();
        Console.WriteLine($"A moto {ID} está ligada.");
    }

    /// <summary>
    /// Desliga a moto.
    /// </summary>
    public override void Desligar()
    {
        base.Desligar();
        Console.WriteLine($"A moto {ID} está desligada.");
    }

    /// <summary>
    /// Realiza a manutenção da moto.
    /// </summary>
    /// <returns>True se a manutenção foi realizada com sucesso; false, caso contrário.</returns>
    public bool RealizarManutencaoMoto()
    {
        // Verifica a condição do Moto.
        var condicaoMoto = VerificarCondicaoMoto();

        // Se o Moto estiver em boas condições, não é necessário realizar manutenção.
        if (condicaoMoto)
        {
            return true;
        }

        // Seleciona os serviços de manutenção necessários.
        var servicosManutencao = SelecionarServicosManutencao(condicaoMoto);

        // Executa os serviços de manutenção.
        foreach (var servico in servicosManutencao)
        {
            servico.Executar();
        }

        // Marca o carro como reparado.
        this.DataManutencao = DateTime.Now;

        // Exibe um resumo dos serviços de manutenção realizados.
        foreach (var servico in servicosManutencao)
        {
            Console.WriteLine($"Serviço de manutenção: {servico.Nome}, Descrição: {servico.Descricao}.");
        }

        return true;
    }

    #endregion

    #region Outros Métodos

    protected override bool VerificarCondicaoMoto()
    {
        // Implemente a lógica para verificar a condição específica do Moto
        // Por enquanto, vamos apenas retornar true como exemplo
        return true;
    }

    // Adicione mais métodos e propriedades conforme necessário

    #endregion
}
