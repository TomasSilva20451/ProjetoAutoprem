﻿/**
 * @file Veiculo.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Definition of the Veiculo class
 * @version 0.2
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */

using System;

public class Veiculo
{
    #region Atributos

    public int ID { get; }
    public bool EstaEmManutencao { get; protected set; }
    public DateTime DataManutencao { get; set; }

    #endregion

    #region Construtores

    /// <summary>
    /// Construtor da classe Veiculo.
    /// </summary>
    /// <param name="id">Identificador único do veículo.</param>
    public Veiculo(int id)
    {
        ID = id;
        EstaEmManutencao = false;
        // TODO: Inicializar outros atributos no construtor, se necessário
    }

    #endregion

    #region Métodos

    /// <summary>
    /// Realiza a manutenção do veículo, se não estiver em manutenção.
    /// </summary>
    /// <returns>True se a manutenção foi realizada com sucesso; False se o veículo já está em manutenção.</returns>
    public bool RealizarManutencao()
    {
        if (!EstaEmManutencao)
        {
            Console.WriteLine($"Realizando manutenção do veículo {ID}.");

            // Verifica a condição do carro
            var condicaoCarro = VerificarCondicaoCarro();

            // Se o carro estiver em boas condições, não é necessário realizar manutenção
            if (condicaoCarro)
            {
                Console.WriteLine($"O veículo {ID} está em boas condições, não é necessário realizar manutenção.");
                return true;
            }

            // Seleciona os serviços de manutenção necessários
            var servicosManutencao = SelecionarServicosManutencao(condicaoCarro);

            // Executa os serviços de manutenção selecionados
            foreach (var servico in servicosManutencao)
            {
                servico.Executar();
            }

            // Marca o carro como reparado
            DataManutencao = DateTime.Now;

            return true;
        }
        else
        {
            Console.WriteLine($"O veículo {ID} já está em manutenção.");
            return false;
        }
    }

    /// <summary>
    /// Verifica a condição do veículo.
    /// </summary>
    /// <returns>True se o veículo estiver em boas condições; False caso contrário.</returns>
    protected virtual bool VerificarCondicaoCarro()
    {
        // Implemente a lógica para verificar a condição do veículo aqui
        // Por enquanto, vamos apenas retornar true como exemplo
        return true;
    }

    /// <summary>
    /// Verifica a condição do veículo.
    /// </summary>
    /// <returns>True se o veículo estiver em boas condições; False caso contrário.</returns>
    protected virtual bool VerificarCondicaoMoto()
    {
        // Implemente a lógica para verificar a condição do veículo aqui
        // Por enquanto, vamos apenas retornar true como exemplo
        return true;
    }

    /// <summary>
    /// Seleciona os serviços de manutenção necessários com base na condição do veículo.
    /// </summary>
    /// <param name="condicaoCarro">Condição do veículo.</param>
    /// <returns>Lista de serviços de manutenção a serem executados.</returns>
    protected virtual List<ServicoManutencao> SelecionarServicosManutencao(bool condicaoCarro)
    {
        // Implemente a lógica para selecionar os serviços de manutenção com base na condição do veículo
        // Por enquanto, vamos retornar uma lista vazia como exemplo
        return new List<ServicoManutencao>();
    }


    /// <summary>
    /// Liga o veículo.
    /// </summary>
    public virtual void Ligar()
    {
        Console.WriteLine($"O veículo {ID} está ligado.");
    }

    /// <summary>
    /// Desliga o veículo.
    /// </summary>
    public virtual void Desligar()
    {
        Console.WriteLine($"O veículo {ID} está desligado.");
    }

    #endregion

    #region Outros Métodos

    // Adicione mais métodos e propriedades conforme necessário

    #endregion
}
