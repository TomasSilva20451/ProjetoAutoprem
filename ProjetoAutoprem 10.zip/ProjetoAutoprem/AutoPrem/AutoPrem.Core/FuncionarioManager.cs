﻿/**
 * @file FuncionarioManager.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Classe que representa o Funcionario Manager
 * @version 0.2
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */

using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    public class FuncionarioManager
    {
        private List<Funcionario> funcionarios;

        public FuncionarioManager()
        {
            funcionarios = new List<Funcionario>();
        }

        public void AdicionarFuncionario(Funcionario funcionario)
        {
            funcionarios.Add(funcionario);
            Console.WriteLine("Funcionário adicionado com sucesso.");
        }

        public void AtualizarFuncionario(int id, string novoNome, string novoEmail, string novoNumeroTelefone)
        {
            var funcionario = funcionarios.FirstOrDefault(f => f.Id == id);
            if (funcionario != null)
            {
                funcionario.Nome = novoNome;
                funcionario.Email = novoEmail;
                funcionario.NumeroTelefone = novoNumeroTelefone;
                Console.WriteLine("Funcionário atualizado com sucesso.");
            }
            else
            {
                Console.WriteLine("Funcionário não encontrado.");
            }
        }

        public void RemoverFuncionario(int id)
        {
            var funcionario = funcionarios.FirstOrDefault(f => f.Id == id);
            if (funcionario != null)
            {
                funcionarios.Remove(funcionario);
                Console.WriteLine("Funcionário removido com sucesso.");
            }
            else
            {
                Console.WriteLine("Funcionário não encontrado.");
            }
        }

        public List<Funcionario> ListarFuncionarios()
        {
            return funcionarios;
        }

    }

}

