﻿/**
 * @file Veiculo.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Definition of the Veiculo class
 * @version 0.2
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */

using System;
using System.Collections.Generic; // Add this if using List<T>


public class Veiculo : Componente
{
    #region Atributos

    public int ID { get; }
    public bool EstaEmManutencao { get; private set; }
    public DateTime DataManutencao { get; set; }

    #endregion

    #region Construtores

    /// <summary>
    /// Construtor da classe Veiculo.
    /// </summary>
    /// <param name="id">Identificador único do veículo.</param>
    public Veiculo(int id)
    {
        ID = id;
        EstaEmManutencao = false;
        // TODO: Inicializar outros atributos no construtor, se necessário
    }

    #endregion

    #region Métodos

    /// <summary>
    /// Overrides the RealizarManutencao method from Componente for Veiculo.
    /// </summary>
    public override void RealizarManutencao()
    {
        if (!EstaEmManutencao)
        {
            EstaEmManutencao = true;
            Console.WriteLine($"Manutenção iniciada para o veículo ID: {ID}");
            // Implement your logic for maintenance here
        }
        else
        {
            Console.WriteLine($"O veículo ID: {ID} já está em manutenção.");
        }
    }

    public override void Substituir()
    {
        // Implement the substitution logic here (if needed)
    }


    /// <summary>
    /// Public method to set the EstaEmManutencao property.
    /// </summary>
    public void SetManutencaoStatus(bool status)
    {
        EstaEmManutencao = status;
        if (status)
        {
            Console.WriteLine($"Veículo ID: {ID} entrou em manutenção.");
        }
        else
        {
            Console.WriteLine($"Veículo ID: {ID} saiu da manutenção.");
        }
    }


    /// <summary>
    /// Verifica a condição do veículo.
    /// </summary>
    /// <returns>True se o veículo estiver em boas condições; False caso contrário.</returns>
    protected virtual bool VerificarCondicaoVeiculo()
    {
        // Implemente a lógica para verificar a condição do veículo
        // Exemplo: verificar se há algum problema específico no veículo
        return true; // ou false, dependendo da lógica real
    }


    /// <summary>
    /// Liga o veículo.
    /// </summary>
    public virtual void Ligar()
    {
        Console.WriteLine($"O veículo {ID} está ligado.");
    }


    /// <summary>
    /// Desliga o veículo.
    /// </summary>
    public virtual void Desligar()
    {
        Console.WriteLine($"O veículo {ID} está desligado.");
    }


    /// <summary>
    /// Seleciona os serviços de manutenção necessários com base na condição do veículo.
    /// </summary>
    /// <param name="condicaoCarro">Condição do veículo.</param>
    /// <returns>Lista de serviços de manutenção a serem executados.</returns>
    protected virtual List<ServicoManutencao> SelecionarServicosManutencao(bool condicaoCarro)
    {

        // Vamos retornar uma lista vazia 
        return new List<ServicoManutencao>();
    }

    #endregion

    #region Outros Métodos


    /// <summary>
    /// Verifica a condição do veículo.
    /// </summary>
    /// <returns>True se o veículo estiver em boas condições; False caso contrário.</returns>
    protected virtual bool VerificarCondicaoCarro()
    {

        // Vamos apenas retornar true
        return true;
    }

    /// <summary>
    /// Verifica a condição do veículo.
    /// </summary>
    /// <returns>True se o veículo estiver em boas condições; False caso contrário.</returns>
    protected virtual bool VerificarCondicaoMoto()
    {

        // Vamos apenas retornar true 
        return true;
    }


    #endregion
}
