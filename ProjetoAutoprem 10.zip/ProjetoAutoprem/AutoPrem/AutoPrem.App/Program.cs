﻿/**
 * @file Program.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Ponto de entrada principal para a aplicação
 * @version 0.2
 * @date 2023-12-18
 * @copyright Copyright (c) 2023
 */

using System;
using AutoPrem.Core;
using AutoPrem.Core.Services;

class Program
{
    #region Variaveis
    private readonly IIOService ioService;
    #endregion

    #region Construtores
    /// <summary>
    /// Inicializa uma nova instância da classe <see cref='Program'/>.
    /// </summary>
    /// <param name="ioService">The IO service.</param>
    public Program(IIOService ioService)
    {
        this.ioService = ioService;
    }
    #endregion

    #region Metodo Principal
    /// <summary>
    /// O ponto de entrada principal para a aplicação.
    /// </summary>
    static void Main()
    {
        Program program = new Program(new ConsoleIOService());
        program.Run();
    }
    #endregion

    #region Metodos Publicos
    /// <summary>
    /// Executa esta instância.
    /// </summary>
    public void Run()
    {
        ExemploUtilizacao();
        ExemploServicosTarefas();
    }
    #endregion

    #region Metodos Privados
    /// <summary>
    /// Exemplo de utilização das classes e serviços implementados.
    /// </summary>
    private void ExemploUtilizacao()
    {
        Veiculo veiculo = new Veiculo(1);
        veiculo.Ligar();
        veiculo.Desligar();
    }

    /// <summary>
    /// Lidar com exceções ao executar a ação relacionada ao veículo.
    /// </summary>
    /// <param name="action">Ação a ser executada.</param>
    /// <param name="sucessoMessage">Mensagem de sucesso a ser exibida.</param>
    private void LidarComVeiculoException(Action action, string sucessoMessage)
    {
        try
        {
            action.Invoke();
            ioService.WriteLine(sucessoMessage);
        }
        catch (Exception ex)
        {
            ioService.WriteLine($"Erro: {ex.Message}");
        }
    }

    /// <summary>
    /// Exemplo de utilização de serviços e tarefas.
    /// </summary>
    private void ExemploServicosTarefas()
    {
        // Serviço de Manutenção

        try
        {
            Veiculo veiculo = new Veiculo(1);
            ServicoManutencao servico = new ServicoManutencao(DateTime.Now, "Manutenção de rotina", veiculo);

            // Se `Veiculo` é uma subclasse de `Componente`, isso deve funcionar
            servico.RealizarManutencao(veiculo);
            ioService.WriteLine("Manutenção realizada com sucesso.");
        }
        catch (Exception ex)
        {
            ioService.WriteLine($"Erro ao realizar manutenção: {ex.Message}");
        }

        // Componente
        try
        {
            Componente componente = new ComponenteEspecifico(); // ComponenteEspecifico não é uma subclasse de Veiculo, ou que o objeto ComponenteEspecifico já está em estado de manutenção
            ServicoManutencao servico = new ServicoManutencao(DateTime.Now, "Manutenção de rotina", componente);
            servico.RealizarManutencao(componente);
            ioService.WriteLine("Manutenção realizada com sucesso.");
        }
        catch (Exception ex)
        {
            ioService.WriteLine($"Erro ao realizar manutenção: {ex.Message}");
        }

        // Tarefa do Funcionário
        try
        {
            // Criação do objeto Funcionario com todos os parâmetros necessários
            Funcionario funcionario = new Funcionario("João", "joao@email.com", "123456789");
            bool sucessoTarefa = funcionario.RealizarTarefa(new ComponenteEspecifico());
            ioService.WriteLine(sucessoTarefa ? "Tarefa realizada com sucesso." : "Erro ao realizar tarefa.");
        }
        catch (Exception ex)
        {
            ioService.WriteLine($"Erro ao realizar tarefa: {ex.Message}");
        }
    }

    #endregion
}
