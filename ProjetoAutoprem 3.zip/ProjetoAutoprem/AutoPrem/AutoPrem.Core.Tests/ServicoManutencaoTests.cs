﻿/**
 * @file ServicoManutencaoTests.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Testes para a classe ServicoManutencao
 * @version 0.1
 * @date 2023-12-18
 * @copyright Copyright (c) 2023
 */

using Microsoft.VisualStudio.TestTools.UnitTesting;
using AutoPrem.Core;
using Moq;
using System;

[TestClass]
public class ServicoManutencaoTests
{
    #region Métodos de Teste

    [TestMethod]
    public void RealizarManutencao_ServicoNaoRealizado_ChamaMetodoRealizarManutencaoDoComponente()
    {
        // Arrange
        var mockComponente = new Mock<Componente>();
        ServicoManutencao servico = new ServicoManutencao(DateTime.Now, "Manutenção de rotina");

        // Act
        servico.RealizarManutencao(mockComponente.Object);

        // Assert
        mockComponente.Verify(c => c.RealizarManutencao(), Times.Once);
    }

    [TestMethod]
    public void RealizarManutencao_ServicoJaRealizado_NaoChamaMetodoRealizarManutencaoDoComponente()
    {
        // Arrange
        var mockComponente = new Mock<Componente>();
        ServicoManutencao servico = new ServicoManutencao(DateTime.Now, "Manutenção de rotina");
        servico.Realizado = true;

        // Act
        servico.RealizarManutencao(mockComponente.Object);

        // Assert
        mockComponente.Verify(c => c.RealizarManutencao(), Times.Never);
    }

    // Adicione mais testes conforme necessário

    #endregion
}