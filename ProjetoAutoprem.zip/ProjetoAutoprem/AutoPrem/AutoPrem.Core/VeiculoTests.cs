﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using AutoPrem.Core;

[TestClass]
public class VeiculoTests
{
    [TestMethod]
    public void TestLigarVeiculo()
    {
        // Arrange
        Veiculo veiculo = new Carro(1);

        // Act
        veiculo.Ligar();

        // Assert
        Assert.IsTrue(veiculo.EstaEmManutencao);
    }

    [TestMethod]
    public void TestDesligarVeiculo()
    {
        // Arrange
        Veiculo veiculo = new Carro(1);

        // Act
        veiculo.Desligar();

        // Assert
        Assert.IsFalse(veiculo.EstaEmManutencao);
    }

    [TestMethod]
    public void TestRealizarManutencaoVeiculo()
    {
        // Arrange
        Veiculo veiculo = new Carro(1);

        // Act
        bool result = veiculo.RealizarManutencao();

        // Assert
        Assert.IsTrue(result);
        Assert.IsTrue(veiculo.EstaEmManutencao);
    }
}
