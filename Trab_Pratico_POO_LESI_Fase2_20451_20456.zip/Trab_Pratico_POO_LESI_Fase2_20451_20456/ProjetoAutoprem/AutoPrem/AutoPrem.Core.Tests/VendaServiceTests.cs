﻿/**
 * @file VendaVeiculoServiceTests.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Testes unitários para a classe VendaVeiculoService.
 * @version 0.1
 * @date 2023-12-17
 * @copyright Copyright (c) 2023
 */

using AutoPrem.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

[TestClass]
public class VendaVeiculoServiceTests
{
    #region Atributos

    // Declaração de atributos de teste aqui (se necessário)

    #endregion
    #region Métodos

    [TestMethod]
    public void AdicionarVeiculoParaVenda_DeveAdicionarVeiculoParaVenda()
    {
        // Arrange
        var vendaVeiculoService = new VendaVeiculoService();
        var veiculo = new MockVeiculo(1, "Marca", "Modelo", 2023);

        // Act
        vendaVeiculoService.AdicionarVeiculoParaVenda(veiculo);

        // Assert
        var veiculosDisponiveis = vendaVeiculoService.ListarVeiculosDisponiveis();
        Assert.IsTrue(veiculosDisponiveis.Contains(veiculo));
    }

    [TestMethod]
    public void RealizarVenda_VeiculoDisponivel_DeveRealizarVenda()
    {
        // Arrange
        var vendaVeiculoService = new VendaVeiculoService();
        var veiculo = new MockVeiculo(1, "Marca", "Modelo", 2023);
        var cliente = new Cliente("NomeCliente", "EmailCliente");
        vendaVeiculoService.AdicionarVeiculoParaVenda(veiculo);

        // Act
        vendaVeiculoService.RealizarVenda(veiculo.ID, cliente);

        // Assert
        var vendasRealizadas = vendaVeiculoService.ObterRegistoVendas();
        Assert.AreEqual(1, vendasRealizadas.Count); // Verifique se uma venda foi registrada
        var vendaRegistrada = vendasRealizadas[0];
        Assert.AreEqual(cliente, vendaRegistrada.Cliente); // Verifique se o cliente coincide
        Assert.AreEqual(veiculo, vendaRegistrada.Veiculo); // Verifique se o veículo coincide
        Assert.IsFalse(vendaVeiculoService.ListarVeiculosDisponiveis().Contains(veiculo)); // Verifique se o veículo não está mais disponível para venda
    }

    [TestMethod]
    public void RealizarVenda_VeiculoNaoDisponivel_NaoDeveRealizarVenda()
    {
        // Arrange
        var vendaVeiculoService = new VendaVeiculoService();
        var veiculo = new MockVeiculo(1, "Marca", "Modelo", 2023);
        var cliente = new Cliente("NomeCliente", "EmailCliente");

        // Act
        vendaVeiculoService.RealizarVenda(veiculo.ID, cliente);

        // Assert
        var vendasRealizadas = vendaVeiculoService.ObterRegistoVendas();
        Assert.AreEqual(0, vendasRealizadas.Count); // Verifique se nenhuma venda foi registrada
    }
    #endregion
}
