﻿/**
 * @file CompraServiceTests.cs
 * @authors Tomás (a20451@alunos.ipca.pt), Telmo (a20456@alunos.ipca.pt)
 * @brief Classe de testes para CompraService
 * @version 0.1
 * @date 2023-12-30
 */

using AutoPrem.Core.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

[TestClass]
public class CompraServiceTests
{

    #region Atributos

    // Declaração de atributos de teste aqui (se necessário)

    #endregion
    #region Métodos
    [TestMethod]
    public void FazerPedidoVeiculo_VeiculoExistente_DeveRealizarPedido()
    {
        // Arrange
        var compraService = new CompraService();
        var veiculoId = 1;
        var quantidade = 2;

        // Act
        compraService.FazerPedidoVeiculo(veiculoId, quantidade);

        // Vamos apenas testar se o método não lança exceções.
    }

    [TestMethod]
    public void FazerPedidoComponente_ComponenteExistente_DeveRealizarPedido()
    {
        // Arrange
        var compraService = new CompraService();
        var componenteId = 1;
        var quantidade = 5;

        // Act
        compraService.FazerPedidoComponente(componenteId, quantidade);

        // Vamos apenas testar se o método não lança exceções.
    }

    [TestMethod]
    public void ProcessarPagamento_DeveProcessarPagamento()
    {
        // Arrange
        var compraService = new CompraService();
        var valorTotal = 1000.00m;

        // Act
        compraService.ProcessarPagamento(valorTotal);

        // Vamos apenas testar se o método não lança exceções.
    }
    #endregion
}
