﻿/**
 * @file AgendamentoServiceTests.cs
 * @brief Classe de testes para AgendamentoService
 * @version 1.0
 * @date 2023-12-17
 * @authors
 *   Tomás Silva (a20451@alunos.ipca.pt)
 *   Telmo (a20456@alunos.ipca.pt)
 */

using AutoPrem.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

[TestClass]
public class AgendamentoServiceTests
{

    #region Atributos

    // Declaração de atributos de teste aqui (se necessário)

    #endregion
    #region Métodos de Teste

    [TestMethod]
    public void AgendarManutencao_DeveAgendarManutencaoComSucesso()
    {
        // Arrange
        var agendamentoService = new AgendamentoService();
        var dataAgendamento = DateTime.Now.AddDays(7);
        var veiculo = new MockVeiculo(1, "Marca", "Modelo", 2024);
        var descricao = "Descrição da manutenção";

        // Act
        agendamentoService.AgendarManutencao(dataAgendamento, veiculo, descricao);

        // Assert
        var agendamentos = agendamentoService.ObterAgendamentos();
        Assert.AreEqual(1, agendamentos.Count);
        var agendamento = agendamentos[0];
        Assert.AreEqual(dataAgendamento, agendamento.DataAgendamento);
        Assert.AreEqual(veiculo, agendamento.Veiculo);
        Assert.AreEqual(descricao, agendamento.Descricao);
    }

    [TestMethod]
    public void AtualizarAgendamento_AgendamentoExistente_DeveAtualizarComSucesso()
    {
        // Arrange
        var agendamentoService = new AgendamentoService();
        var dataAgendamento = DateTime.Now.AddDays(7);
        var veiculo = new MockVeiculo(1, "Marca", "Modelo", 2024);
        var descricao = "Descrição da manutenção";
        agendamentoService.AgendarManutencao(dataAgendamento, veiculo, descricao);

        // Act
        var novoDataAgendamento = DateTime.Now.AddDays(14);
        var novaDescricao = "Nova descrição da manutenção";
        agendamentoService.AtualizarAgendamento(1, novoDataAgendamento, novaDescricao);

        // Assert
        var agendamentos = agendamentoService.ObterAgendamentos();
        Assert.AreEqual(1, agendamentos.Count);
        var agendamentoAtualizado = agendamentos[0];
        Assert.AreEqual(novoDataAgendamento, agendamentoAtualizado.DataAgendamento);
        Assert.AreEqual(novaDescricao, agendamentoAtualizado.Descricao);
    }

    [TestMethod]
    public void CancelarAgendamento_AgendamentoExistente_DeveCancelarComSucesso()
    {
        // Arrange
        var agendamentoService = new AgendamentoService();
        var dataAgendamento = DateTime.Now.AddDays(7);
        var veiculo = new MockVeiculo(1, "Marca", "Modelo", 2024);
        var descricao = "Descrição da manutenção";
        agendamentoService.AgendarManutencao(dataAgendamento, veiculo, descricao);

        // Act
        agendamentoService.CancelarAgendamento(1);

        // Assert
        var agendamentos = agendamentoService.ObterAgendamentos();
        Assert.AreEqual(0, agendamentos.Count);
    }

    #endregion
}
