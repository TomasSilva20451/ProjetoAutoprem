﻿/**
* @file AgendamentoManutencao.cs
* @author Tomás (a20451@alunos.ipca.pt)
* @author Telmo (a20456@alunos.ipca.pt)
* @brief Classe que representa um agendamento de manutenção
* @version 0.1
* @date 2023-12-22
* 
* @copyright Copyright (c) 2023
* 
*/

using System;

namespace AutoPrem.Core
{
    /// <summary>
    /// Classe que representa um agendamento de manutenção.
    /// </summary>
    public class AgendamentoManutencao
    {
        #region Atributos
        // Os atributos são definidos pelas propriedades abaixo.
        #endregion

        #region Propriedades
        /// <summary>
        /// Identificador único do agendamento.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Data de agendamento da manutenção.
        /// </summary>
        public DateTime DataAgendamento { get; set; }

        /// <summary>
        /// Descrição da manutenção.
        /// </summary>
        public string Descricao { get; set; } = "Manutenção de rotina";

        /// <summary>
        /// Componente a ser mantido.
        /// </summary>
        public Componente Componente { get; set; } = new ComponenteEspecifico();

        /// <summary>
        /// Veículo associado ao agendamento.
        /// </summary>
        public Veiculo? Veiculo { get; set; }
        #endregion

        #region Construtores
        // Construtores podem ser adicionados aqui.
        #endregion

        #region Métodos

        /// <summary>
        /// Agenda uma manutenção.
        /// </summary>
        /// <param name="dataAgendamento">Data de agendamento da manutenção.</param>
        /// <param name="descricao">Descrição da manutenção.</param>
        /// <param name="componente">Componente a ser mantido.</param>
        /// <param name="veiculo">Veículo associado à manutenção.</param>
        /// <returns>True se a manutenção foi agendada com sucesso; caso contrário, false.</returns>
        public bool AgendarManutencao(DateTime dataAgendamento, string descricao, Componente componente, Veiculo veiculo)
        {
            // Lógica para agendar a manutenção aqui.
            // Retorne true se a manutenção for agendada com sucesso; caso contrário, false.
            return true;
        }

        /// <summary>
        /// Cancela uma manutenção agendada.
        /// </summary>
        /// <returns>True se a manutenção foi cancelada com sucesso; caso contrário, false.</returns>
        public bool CancelarManutencao()
        {
            // Lógica para cancelar a manutenção aqui.
            // Retorne true se a manutenção for cancelada com sucesso; caso contrário, false.
            return true;
        }

        #endregion

        #region Overrides
        // Métodos override, como ToString, Equals, GetHashCode, podem ser adicionados aqui.
        #endregion

        #region Outros Métodos
        // Outros métodos que não se enquadram nas categorias acima podem ser adicionados aqui.
        #endregion

        #region Destrutores
        // Destrutores, se necessários, podem ser adicionados aqui.
        #endregion
    }
}
