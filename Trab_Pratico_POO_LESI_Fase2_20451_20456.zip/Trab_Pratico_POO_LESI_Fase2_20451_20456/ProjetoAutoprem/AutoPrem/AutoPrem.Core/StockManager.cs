﻿/**
 * @file StockManager.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe gerenciadora para operações de estoque de componentes
 * @version 0.1
 * @date 2023-12-17
 * @copyright Copyright (c) 2023
 */

using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    /// <summary>
    /// Gerencia as operações de estoque relacionadas a componentes, como adicionar, atualizar e remover.
    /// </summary>
    public class StockManager
    {
        #region Propriedades
        private List<Componente> componentes;
        #endregion

        #region Construtores
        /// <summary>
        /// Construtor padrão que inicializa a lista de componentes.
        /// </summary>
        public StockManager()
        {
            componentes = new List<Componente>();
        }
        #endregion

        #region Métodos

        /// <summary>
        /// Adiciona um novo componente ao estoque.
        /// </summary>
        /// <param name="componente">Componente a ser adicionado.</param>
        /// <returns>True se o componente for adicionado com sucesso, false em caso de falha.</returns>
        public bool AdicionarComponente(Componente componente)
        {
            componentes.Add(componente);
            return true; // Componente adicionado ao estoque com sucesso
        }

        /// <summary>
        /// Atualiza as informações de um componente existente.
        /// </summary>
        /// <param name="id">ID do componente a ser atualizado.</param>
        /// <param name="novaDescricao">Nova descrição do componente.</param>
        /// <returns>True se o componente for atualizado com sucesso, false se não for encontrado.</returns>
        public bool AtualizarComponente(int id, string novaDescricao)
        {
            var componente = componentes.FirstOrDefault(c => c.Id == id);
            if (componente != null)
            {
                componente.Descricao = novaDescricao;
                return true; // Componente atualizado com sucesso
            }
            else
            {
                return false; // Componente não encontrado
            }
        }

        /// <summary>
        /// Remove um componente do estoque pelo ID.
        /// </summary>
        /// <param name="id">ID do componente a ser removido.</param>
        /// <returns>True se o componente for removido com sucesso, false se não for encontrado.</returns>
        public bool RemoverComponente(int id)
        {
            var componente = componentes.FirstOrDefault(c => c.Id == id);
            if (componente != null)
            {
                componentes.Remove(componente);
                return true; // Componente removido com sucesso
            }
            else
            {
                return false; // Componente não encontrado
            }
        }

        /// <summary>
        /// Lista todos os componentes no estoque.
        /// </summary>
        /// <returns>Lista de componentes.</returns>
        public List<Componente> ListarComponentes()
        {
            return componentes;
        }

        #endregion
    }
}
