﻿/**
 * @file Funcionario.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe que representa um funcionário
 * @version 0.1
 * @date 2023-12-17
 * @copyright Copyright (c) 2023
 */

public class Funcionario
{
    #region Propriedades

    /// <summary>
    /// Identificador único do funcionário.
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    /// Nome do funcionário.
    /// </summary>
    public string Nome { get; set; }

    /// <summary>
    /// Email do funcionário.
    /// </summary>
    public string Email { get; set; }

    /// <summary>
    /// Número de telefone do funcionário.
    /// </summary>
    public string NumeroTelefone { get; set; }

    #endregion

    #region Construtores

    /// <summary>
    /// Construtor da classe Funcionario.
    /// </summary>
    /// <param name="nome">Nome do funcionário.</param>
    /// <param name="email">Email do funcionário.</param>
    /// <param name="numeroTelefone">Número de telefone do funcionário.</param>
    public Funcionario(string nome, string email, string numeroTelefone)
    {
        Nome = nome;
        Email = email;
        NumeroTelefone = numeroTelefone;
    }

    #endregion

    #region Métodos

    /// <summary>
    /// Realiza uma tarefa utilizando um componente.
    /// Este método verifica se o componente está danificado e, se estiver, realiza a substituição.
    /// </summary>
    /// <param name="componente">Componente a ser utilizado na tarefa.</param>
    /// <returns>
    /// Retorna true se a tarefa foi realizada com sucesso. Se o componente estiver danificado, 
    /// a substituição é feita e a tarefa é considerada bem-sucedida.
    /// </returns>
    public bool RealizarTarefa(Componente componente)
    {
        if (componente.EstaDanificado)
        {
            componente.Substituir();
            return true; // Tarefa realizada com sucesso após substituição do componente
        }

        return true; // Tarefa realizada com sucesso sem necessidade de substituição
    }

    // Adicione mais métodos e propriedades conforme necessário

    #endregion
}
