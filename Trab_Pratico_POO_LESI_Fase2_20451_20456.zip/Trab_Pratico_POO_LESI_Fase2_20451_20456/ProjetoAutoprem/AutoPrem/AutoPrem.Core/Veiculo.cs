﻿/**
 * @file Veiculo.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Definição da classe Veiculo
 * @version 0.2
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */

using System;
using System.Collections.Generic;

/// <summary>
/// Classe abstrata Veiculo, estendendo a classe Componente. 
/// Representa a base para diferentes tipos de veículos.
/// </summary>
public abstract class Veiculo : Componente
{
    #region Propriedades
    public int ID { get; }
    public string Modelo { get; set; }
    public string Marca { get; set; }
    public int Ano { get; set; }
    public bool EstaEmManutencao { get; private set; }
    public DateTime DataManutencao { get; set; }
    #endregion

    #region Construtores
    public Veiculo(int id, string modelo, string marca, int ano)
    {
        ID = id;
        Modelo = modelo;
        Marca = marca;
        Ano = ano;
        EstaEmManutencao = false;
    }
    #endregion

    #region Métodos Abstratos

    public abstract override bool RealizarManutencao();
    public abstract override bool Substituir();

    #endregion

    #region Métodos

    /// <summary>
    /// Define o status de manutenção do veículo.
    /// </summary>
    /// <param name="status">Status de manutenção a ser definido.</param>
    public void SetManutencaoStatus(bool status)
    {
        EstaEmManutencao = status;
    }

    /// <summary>
    /// Verifica a condição geral do veículo. Método a ser sobrescrito em subclasses.
    /// </summary>
    /// <returns>True se o veículo estiver em boas condições; False caso contrário.</returns>
    protected virtual bool VerificarCondicaoVeiculo()
    {
        // Lógica para verificar a condição do veículo.
        return true; // ou false, dependendo da lógica real
    }

    /// <summary>
    /// Ligar o veículo. Método a ser sobrescrito em subclasses.
    /// </summary>
    /// <returns>True se o veículo for ligado com sucesso.</returns>
    public virtual bool Ligar()
    {
        // Lógica para ligar o veículo.
        return true; // Por exemplo, sempre retornar true por enquanto
    }

    /// <summary>
    /// Desligar o veículo. Método a ser sobrescrito em subclasses.
    /// </summary>
    /// <returns>True se o veículo for desligado com sucesso.</returns>
    public virtual bool Desligar()
    {
        // Lógica para desligar o veículo.
        return true; // Por exemplo, sempre retornar true por enquanto
    }

    #endregion

    #region Métodos Auxiliares

    /// <summary>
    /// Seleciona os serviços de manutenção necessários para um carro. Método a ser sobrescrito em subclasses.
    /// </summary>
    /// <param name="condicaoCarro">Condição do carro.</param>
    /// <returns>Uma lista de serviços de manutenção necessários.</returns>
    protected virtual List<ServicoManutencao> SelecionarServicosManutencao(bool condicaoCarro)
    {
        // Retorna uma lista de serviços de manutenção baseada na condição do carro.
        return new List<ServicoManutencao>();
    }

    /// <summary>
    /// Verifica a condição de um carro. Método a ser sobrescrito em subclasses específicas para carros.
    /// </summary>
    /// <returns>True se o carro estiver em boas condições; False caso contrário.</returns>
    protected virtual bool VerificarCondicaoCarro()
    {
        // Lógica para verificar a condição do carro.
        return true;
    }

    /// <summary>
    /// Verifica a condição de uma moto. Método a ser sobrescrito em subclasses específicas para motos.
    /// </summary>
    /// <returns>True se a moto estiver em boas condições; False caso contrário.</returns>
    protected virtual bool VerificarCondicaoMoto()
    {
        // Lógica para verificar a condição da moto.
        return true;
    }

    #endregion
}
