﻿/**
 * @file ServicoManutencao.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Definição da classe ServicoManutencao
 * @version 0.2
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */

using System;
using AutoPrem.Core;

/// <summary>
/// Classe representando um serviço de manutenção.
/// </summary>
public class ServicoManutencao
{
    #region Propriedades

    /// <summary>
    /// Data de agendamento do serviço de manutenção.
    /// </summary>
    public DateTime DataAgendamento { get; }

    /// <summary>
    /// Nome do serviço de manutenção.
    /// </summary>
    public string? Nome { get; set; }

    /// <summary>
    /// Descrição do serviço de manutenção.
    /// </summary>
    public string Descricao { get; private set; }

    /// <summary>
    /// Indica se o serviço de manutenção foi realizado.
    /// </summary>
    public bool Realizado { get; set; }

    /// <summary>
    /// Componente associado ao serviço de manutenção.
    /// </summary>
    public Componente Componente { get; set; }

    /// <summary>
    /// Agendamento associado ao serviço de manutenção.
    /// </summary>
    public AgendamentoManutencao? Agendamento { get; set; }

    /// <summary>
    /// Cliente associado ao serviço de manutenção.
    /// </summary>
    public Cliente? Cliente { get; set; }

    #endregion

    #region Construtores

    /// <summary>
    /// Construtor da classe ServicoManutencao.
    /// </summary>
    public ServicoManutencao(DateTime dataAgendamento, string descricao, Componente componente)
    {
        DataAgendamento = dataAgendamento;
        Descricao = descricao;
        Componente = componente;
        Realizado = false;
    }

    #endregion

    #region Métodos

    /// <summary>
    /// Realiza a manutenção utilizando um componente específico.
    /// Se o componente é um veículo e não está em manutenção, marca como em manutenção.
    /// </summary>
    /// <param name="componente">Componente a ser mantido.</param>
    public void RealizarManutencao(Componente componente)
    {
        if (this.Componente is Veiculo veiculo && !veiculo.EstaEmManutencao)
        {
            veiculo.SetManutencaoStatus(true);
            Realizado = true;
        }
    }

    /// <summary>
    /// Agenda manutenção para um cliente especificado.
    /// Se a manutenção já foi realizada, exibe uma mensagem.
    /// </summary>
    /// <param name="cliente">Cliente para o qual a manutenção está sendo agendada.</param>
    public void AgendarManutencao(Cliente cliente)
    {
        if (!Realizado)
        {
            Cliente = cliente;
            Realizado = true;
        }
    }

    /// <summary>
    /// Cria e retorna um novo agendamento de manutenção.
    /// </summary>
    /// <returns>Um novo agendamento de manutenção.</returns>
    public AgendamentoManutencao AgendarManutencao()
    {
        AgendamentoManutencao agendamento = new AgendamentoManutencao();
        agendamento.DataAgendamento = DataAgendamento;
        agendamento.Descricao = Descricao;
        agendamento.Componente = Componente;
        Agendamento = agendamento;
        Realizado = true;
        return agendamento;
    }

    /// <summary>
    /// Executa o serviço de manutenção.
    /// </summary>
    public void Executar()
    {
        // Implemente a execução do serviço de manutenção aqui.
    }

    #endregion
}
