﻿/**
 * @file MotoTests.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Testes para a classe Moto
 * @version 0.1
 * @date 2023-12-18
 * @copyright Copyright (c) 2023
 */

using Microsoft.VisualStudio.TestTools.UnitTesting;
using AutoPrem.Core;

[TestClass]
public class MotoTests
{
    #region Atributos

    // Declaração de atributos de teste aqui (se necessário)

    #endregion
    #region Métodos de Teste

    [TestMethod]
    public void RealizarManutencaoMoto_ManutencaoBemSucedida_RetornaTrue()
    {
        // Arrange
        Moto moto = new Moto(1);

        // Act
        bool resultado = moto.RealizarManutencaoMoto();

        // Assert
        Assert.IsTrue(resultado);
    }

    [TestMethod]
    public void RealizarManutencaoMoto_MotoEmManutencao_RetornaFalse()
    {
        // Arrange
        Moto moto = new Moto(2);
        // Forçar a moto a estar em manutenção
        moto.RealizarManutencaoMoto(); // Simular manutenção anterior

        // Act
        bool resultado = moto.RealizarManutencaoMoto();

        // Assert
        Assert.IsFalse(resultado);
    }

    [TestMethod]
    public void LigarMoto_MotoDesligada_LigaMoto()
    {
        // Arrange
        Moto moto = new Moto(3);

        // Act
        moto.Ligar();

        // Assert
        Assert.IsTrue(moto.EstaEmManutencao);
    }

    [TestMethod]
    public void DesligarMoto_MotoLigada_DesligaMoto()
    {
        // Arrange
        Moto moto = new Moto(4);

        // Act
        moto.Desligar();

        // Assert
        Assert.IsFalse(moto.EstaEmManutencao);
    }

    // Adicione mais testes conforme necessário

    #endregion
}