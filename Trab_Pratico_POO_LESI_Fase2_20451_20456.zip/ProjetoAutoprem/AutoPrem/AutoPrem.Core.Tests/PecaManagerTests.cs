﻿/**
 * @file PecaManagerTests.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Testes unitários para a classe PecaManager.
 * @version 0.1
 * @date 2023-12-17
 * @copyright Copyright (c) 2023
 */

using AutoPrem.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

[TestClass]
public class PecaManagerTests
{
    #region Atributos

    // Declaração de atributos de teste aqui (se necessário)

    #endregion
    #region Métodos
    [TestMethod]
    public void AdicionarPeca_DeveAdicionarPeca()
    {
        // Arrange
        var pecaManager = new PecaManager();
        var peca = new ComponenteEspecifico(); // Use a classe derivada ComponenteEspecifico

        // Act
        pecaManager.AdicionarPeca(peca);

        // Assert
        var pecas = pecaManager.ListarPecas();
        Assert.IsTrue(pecas.Contains(peca));
    }

    [TestMethod]
    public void AtualizarPeca_PecaExistente_DeveAtualizar()
    {
        // Arrange
        var pecaManager = new PecaManager();
        var peca = new ComponenteEspecifico();
        pecaManager.AdicionarPeca(peca);

        // Act
        var pecaAtualizada = new ComponenteEspecifico();
        pecaManager.AtualizarPeca(peca.Id, pecaAtualizada);

        // Assert
        var pecaAtualizadaNoManager = pecaManager.ObterPecaPorId(peca.Id);
        Assert.IsNotNull(pecaAtualizadaNoManager);
        if (pecaAtualizadaNoManager != null)
        {
            Assert.AreEqual(peca.Id, pecaAtualizadaNoManager.Id);
            // Você pode comparar outras propriedades conforme necessário
        }
    }

    [TestMethod]
    public void RemoverPeca_PecaExistente_DeveRemover()
    {
        // Arrange
        var pecaManager = new PecaManager();
        var peca = new ComponenteEspecifico();
        pecaManager.AdicionarPeca(peca);

        // Act
        pecaManager.RemoverPeca(peca.Id);

        // Assert
        var pecas = pecaManager.ListarPecas();
        Assert.IsFalse(pecas.Contains(peca));
    }
    #endregion
}
