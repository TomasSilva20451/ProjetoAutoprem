﻿/**
 * @file VeiculoManagerTests.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Testes unitários para a classe VeiculoManager.
 * @version 0.1
 * @date 2023-12-17
 * @copyright Copyright (c) 2023
 */

using AutoPrem.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace AutoPrem.Core.Tests
{
    [TestClass]
    public class VeiculoManagerTests
    {
        #region Atributos

        // Declaração de atributos de teste aqui (se necessário)

        #endregion
        #region Métodos

        [TestMethod]
        public void AdicionarVeiculo_DeveAdicionarVeiculo()
        {
            // Arrange
            var veiculoManager = new VeiculoManager();
            var veiculo = new MockVeiculo(1, "Modelo", "Marca", 2024);

            // Act
            veiculoManager.AdicionarVeiculo(veiculo);

            // Assert
            var veiculos = veiculoManager.ListarVeiculos();
            Assert.IsTrue(veiculos.Contains(veiculo));
        }

        [TestMethod]
        public void ObterVeiculoPorId_VeiculoExistente_DeveRetornarVeiculo()
        {
            // Arrange
            var veiculoManager = new VeiculoManager();
            var veiculo = new MockVeiculo(1, "Modelo", "Marca", 2024);
            veiculoManager.AdicionarVeiculo(veiculo);

            // Act
            var veiculoObtido = veiculoManager.ObterVeiculoPorId(1);

            // Assert
            Assert.IsNotNull(veiculoObtido);
            Assert.AreEqual(1, veiculoObtido.ID);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ObterVeiculoPorId_VeiculoNaoExistente_DeveLancarExcecao()
        {
            // Arrange
            var veiculoManager = new VeiculoManager();

            // Act
            var veiculoObtido = veiculoManager.ObterVeiculoPorId(1);

            // Assert (Exceção esperada)
        }

        [TestMethod]
        public void AtualizarVeiculo_VeiculoExistente_DeveAtualizar()
        {
            // Arrange
            var veiculoManager = new VeiculoManager();
            var veiculo = new MockVeiculo(1, "Modelo", "Marca", 2024);
            veiculoManager.AdicionarVeiculo(veiculo);
            var veiculoAtualizado = new MockVeiculo(1, "NovoModelo", "NovaMarca", 2024);

            // Act
            veiculoManager.AtualizarVeiculo(1, veiculoAtualizado);

            // Assert
            var veiculoAtual = veiculoManager.ObterVeiculoPorId(1);
            Assert.AreEqual("NovoModelo", veiculoAtual.Modelo);
            Assert.AreEqual("NovaMarca", veiculoAtual.Marca);
        }

        [TestMethod]
        public void RemoverVeiculo_VeiculoExistente_DeveRemover()
        {
            // Arrange
            var veiculoManager = new VeiculoManager();
            var veiculo = new MockVeiculo(1, "Modelo", "Marca", 2024);
            veiculoManager.AdicionarVeiculo(veiculo);

            // Act
            veiculoManager.RemoverVeiculo(1);

            // Assert
            var veiculos = veiculoManager.ListarVeiculos();
            Assert.IsFalse(veiculos.Contains(veiculo));
        }

        #endregion
    }
}
