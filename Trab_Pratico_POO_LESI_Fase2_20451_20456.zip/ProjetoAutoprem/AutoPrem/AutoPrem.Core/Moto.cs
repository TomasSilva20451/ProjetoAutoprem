﻿/**
 * @file Moto.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Definição da classe Moto, derivada de Veiculo
 * @version 0.2
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */

using System;

/// <summary>
/// Classe Moto, derivada da classe base Veiculo.
/// Especifica comportamentos e propriedades de uma moto.
/// </summary>
public class Moto : Veiculo
{
    #region Construtores
    /// <summary>
    /// Construtor para criar uma nova instância de Moto.
    /// </summary>
    /// <param name="id">Identificador da moto.</param>
    public Moto(int id) : base(id, "ModeloDaMoto", "MarcaDaMoto", 2024)
    {
        // Inicializa atributos específicos da Moto, se necessário
    }
    #endregion

    #region Métodos Overrides

    /// <summary>
    /// Realiza a manutenção específica da moto.
    /// </summary>
    /// <returns>True se a manutenção for bem-sucedida; caso contrário, false.</returns>
    public override bool RealizarManutencao()
    {
        // Implementar a lógica de manutenção específica para Moto aqui.
        bool maintenanceSuccessful = true; // Substituir pela lógica real.
        return maintenanceSuccessful;
    }

    /// <summary>
    /// Substitui componentes específicos da moto.
    /// </summary>
    /// <returns>True se a substituição for bem-sucedida; caso contrário, false.</returns>
    public override bool Substituir()
    {
        // Implementar a lógica de substituição específica para Moto aqui.
        bool substitutionSuccessful = true; // Substituir pela lógica real.
        return substitutionSuccessful;
    }

    /// <summary>
    /// Liga a moto.
    /// </summary>
    /// <returns>True se a moto for ligada com sucesso.</returns>
    public override bool Ligar()
    {
        base.Ligar();
        return true; // Assume que o processo de ligar sempre tem sucesso.
    }

    /// <summary>
    /// Desliga a moto.
    /// </summary>
    /// <returns>True se a moto for desligada com sucesso.</returns>
    public override bool Desligar()
    {
        base.Desligar();
        return true; // Assume que o processo de desligar sempre tem sucesso.
    }

    #endregion

    #region Métodos Específicos da Moto

    /// <summary>
    /// Realiza a manutenção da moto verificando sua condição e selecionando os serviços apropriados.
    /// </summary>
    /// <returns>True se a manutenção for realizada com sucesso.</returns>
    public bool RealizarManutencaoMoto()
    {
        var condicaoMoto = VerificarCondicaoMoto();

        if (condicaoMoto)
        {
            return true; // Retorna true se a condição da moto estiver boa.
        }

        var servicosManutencao = SelecionarServicosManutencao(condicaoMoto);

        foreach (var servico in servicosManutencao)
        {
            servico.Executar();
        }

        this.DataManutencao = DateTime.Now;

        foreach (var servico in servicosManutencao)
        {
            // Aqui poderiam ser incluídas mensagens de console para cada serviço.
        }

        return true; // Retorna true após a realização da manutenção.
    }

    protected override bool VerificarCondicaoMoto()
    {
        // Implementar verificação da condição da moto aqui
        return true; // Exemplo: sempre assume que a condição é boa
    }

    #endregion

    #region Outros Métodos e Propriedades

    // Adicione mais métodos e propriedades conforme necessário

    #endregion
}
