﻿/**
 * @file Venda.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe Venda de Veículo
 * @version 0.2
 * @date 2023-12-30
 * @remarks ADOÇÃO ADEQUADA DAS NORMAS CLS; DOCUMENTAÇÃO ADEQUADA DO CÓDIGO; ESTRUTURA DE PASTAS, NOMES E TIPOS DOS PROJETOS, NOMES DE MÉTODOS E CLASSES, NOME DO FICHEIRO A SUBMETER
 */

using System;
namespace AutoPrem.Core
{
    public class Venda
    {
        #region Propriedades
        public Cliente Cliente { get; private set; }
        public Veiculo Veiculo { get; private set; }
        public DateTime DataVenda { get; private set; }
        #endregion

        #region Construtores
        public Venda(Cliente cliente, Veiculo veiculo)
        {
            Cliente = cliente;
            Veiculo = veiculo;
            DataVenda = DateTime.Now;
        }
        #endregion

        #region Métodos

        // Outros detalhes da venda...

        #endregion
    }
}
