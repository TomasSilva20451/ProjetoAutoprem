﻿/**
 * @file Carro.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Definition of the Carro class, derived from Veiculo
 * @version 0.3
 * @date 2023-12-23
 * @copyright Copyright (c) 2023
 */

using System;
using System.Collections.Generic;

/// <summary>
/// Classe Carro, que herda da classe Veiculo.
/// </summary>
public class Carro : Veiculo
{
    #region Construtores
    /// <summary>
    /// Construtor para criar uma nova instância de Carro.
    /// </summary>
    /// <param name="id">Identificador do carro.</param>
    public Carro(int id) : base(id, "ModeloDoCarro", "MarcaDoCarro", 2024)
    {
        this.DataManutencao = DateTime.Now;
    }
    #endregion

    #region Métodos

    /// <summary>
    /// Realiza a manutenção específica do carro.
    /// </summary>
    /// <returns>True se a manutenção for bem-sucedida; caso contrário, false.</returns>
    public override bool RealizarManutencao()
    {
        // Implementar a lógica de manutenção específica para Carro aqui.
        // Retornar true se a manutenção for bem-sucedida, caso contrário false.
        bool maintenanceSuccessful = true; // Substituir pela lógica real.
        return maintenanceSuccessful;
    }

    /// <summary>
    /// Realiza a substituição de componentes específicos do carro.
    /// </summary>
    /// <returns>True se a substituição for bem-sucedida; caso contrário, false.</returns>
    public override bool Substituir()
    {
        // Implementar a lógica de substituição específica para Carro aqui.
        // Retornar true se a substituição for bem-sucedida, caso contrário false.
        bool substitutionSuccessful = true; // Substituir pela lógica real.
        return substitutionSuccessful;
    }

    /// <summary>
    /// Liga o carro.
    /// </summary>
    /// <returns>True se o carro for ligado com sucesso.</returns>
    public override bool Ligar()
    {
        base.Ligar();
        return true; // Assumindo que o processo de ligar sempre tem sucesso.
    }

    /// <summary>
    /// Desliga o carro.
    /// </summary>
    /// <returns>True se o carro for desligado com sucesso.</returns>
    public override bool Desligar()
    {
        base.Desligar();
        return true; // Assumindo que o processo de desligar sempre tem sucesso.
    }

    /// <summary>
    /// Realiza a manutenção do carro verificando sua condição e selecionando os serviços apropriados.
    /// </summary>
    /// <returns>True se a manutenção for realizada com sucesso.</returns>
    public bool RealizarManutencaoCarro()
    {
        var condicaoCarro = VerificarCondicaoCarro();

        if (condicaoCarro)
        {
            return true; // Retorna true se a condição do carro estiver boa.
        }

        var servicosManutencao = SelecionarServicosManutencao(condicaoCarro);

        foreach (var servico in servicosManutencao)
        {
            servico.Executar();
        }

        this.DataManutencao = DateTime.Now;

        foreach (var servico in servicosManutencao)
        {
            // Aqui poderiam ser incluídas mensagens de console para cada serviço.
        }

        return true; // Retorna true após a realização da manutenção.
    }

    // Outros métodos e propriedades podem ser adicionados aqui conforme necessário.
    #endregion

    #region Outros Métodos
    // Métodos adicionais podem ser adicionados aqui.
    #endregion
}
