﻿/**
 * @file ServicoManutencaoService.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe ServicoManutencaoService responsável por agendar e realizar manutenções.
 * @version 0.1
 * @date 2023-12-17
 * @copyright Copyright (c) 2023
 */

using System;
using AutoPrem.Core.Services;

namespace AutoPrem.Core
{
    /// <summary>
    /// Serviço responsável por agendar e realizar manutenções em veículos.
    /// </summary>
    public class ServicoManutencaoService
    {
        #region Atributos e Construtores
        private ServicoManutencao _servicoManutencao;

        /// <summary>
        /// Construtor da classe ServicoManutencaoService.
        /// </summary>
        /// <param name="servicoManutencao">Instância de ServicoManutencao associada ao serviço.</param>
        public ServicoManutencaoService(ServicoManutencao servicoManutencao)
        {
            _servicoManutencao = servicoManutencao;
        }
        #endregion

        #region Métodos

        /// <summary>
        /// Agenda uma manutenção se ainda não foi realizada.
        /// Retorna verdadeiro se a manutenção for agendada com sucesso. 
        /// Retorna falso se a manutenção já foi realizada anteriormente ou se o componente associado não é um veículo.
        /// </summary>
        /// <returns>True se a manutenção foi agendada com sucesso; False se já foi realizada anteriormente ou o componente não é um veículo.</returns>
        public bool AgendarManutencao()
        {
            if (!_servicoManutencao.Realizado && _servicoManutencao.Componente is Veiculo veiculo)
            {
                _servicoManutencao.Agendamento = new AgendamentoManutencao
                {
                    DataAgendamento = _servicoManutencao.DataAgendamento,
                    Descricao = _servicoManutencao.Descricao
                };
                _servicoManutencao.Realizado = true;
                return true; // Manutenção agendada com sucesso
            }
            return false; // Manutenção já realizada anteriormente ou componente não é um veículo
        }

        /// <summary>
        /// Realiza a manutenção de um veículo para um cliente específico.
        /// Retorna verdadeiro se a manutenção for realizada com sucesso.
        /// Retorna falso se o veículo já estiver em manutenção.
        /// </summary>
        /// <param name="veiculo">Veículo a ser mantido.</param>
        /// <param name="cliente">Cliente associado à manutenção.</param>
        /// <returns>True se a manutenção foi realizada com sucesso; False se o veículo já estiver em manutenção.</returns>
        public bool RealizarManutencao(Veiculo veiculo, Cliente cliente)
        {
            if (!veiculo.EstaEmManutencao)
            {
                _servicoManutencao = new ServicoManutencao(DateTime.Now, "Manutenção de rotina", veiculo)
                {
                    Cliente = cliente
                };
                return true; // Manutenção realizada com sucesso
            }
            return false; // Veículo já está em manutenção
        }

        #endregion
    }
}
