﻿/**
 * @file AgendamentoService.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe que representa um agendamento service
 * @version 0.1
 * @date 2023-12-30
 * @remarks ADOÇÃO ADEQUADA DAS NORMAS CLS; DOCUMENTAÇÃO ADEQUADA DO CÓDIGO; ESTRUTURA DE PASTAS, NOMES E TIPOS DOS PROJETOS, NOMES DE MÉTODOS E CLASSES, NOME DO FICHEIRO A SUBMETER
 */

using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    public class AgendamentoService
    {
        #region Propriedades
        // Lista para armazenar os agendamentos de manutenção.
        private List<AgendamentoManutencao> agendamentos;
        // Identificador para o próximo agendamento.
        private int nextId = 1;
        #endregion

        #region Construtores
        /// <summary>
        /// Construtor padrão que inicializa a lista de agendamentos.
        /// </summary>
        public AgendamentoService()
        {
            agendamentos = new List<AgendamentoManutencao>();
        }
        #endregion

        #region Métodos

        /// <summary>
        /// Agenda uma manutenção para um veículo.
        /// </summary>
        /// <param name="data">Data da manutenção.</param>
        /// <param name="veiculo">Veículo para manutenção.</param>
        /// <param name="descricao">Descrição da manutenção.</param>
        /// <returns>True se a manutenção foi agendada com sucesso; caso contrário, false.</returns>
        public bool AgendarManutencao(DateTime data, Veiculo veiculo, string descricao)
        {
            var agendamento = new AgendamentoManutencao
            {
                Id = nextId++,
                DataAgendamento = data,
                Veiculo = veiculo,
                Descricao = descricao
            };
            agendamentos.Add(agendamento);
            return true; // Assume que a adição à lista é sempre bem-sucedida.
        }

        /// <summary>
        /// Atualiza os detalhes de um agendamento existente.
        /// </summary>
        /// <param name="id">Identificador do agendamento.</param>
        /// <param name="novaData">Nova data para a manutenção.</param>
        /// <param name="novaDescricao">Nova descrição da manutenção.</param>
        /// <returns>True se o agendamento foi atualizado com sucesso; caso contrário, false.</returns>
        public bool AtualizarAgendamento(int id, DateTime novaData, string novaDescricao)
        {
            var agendamento = agendamentos.FirstOrDefault(a => a.Id == id);
            if (agendamento != null)
            {
                agendamento.DataAgendamento = novaData;
                agendamento.Descricao = novaDescricao;
                return true; // Agendamento atualizado com sucesso.
            }
            return false; // Agendamento não encontrado.
        }

        /// <summary>
        /// Cancela um agendamento existente.
        /// </summary>
        /// <param name="id">Identificador do agendamento a ser cancelado.</param>
        /// <returns>True se o agendamento foi cancelado com sucesso; caso contrário, false.</returns>
        public bool CancelarAgendamento(int id)
        {
            var agendamento = agendamentos.FirstOrDefault(a => a.Id == id);
            if (agendamento != null)
            {
                agendamentos.Remove(agendamento);
                return true; // Agendamento cancelado com sucesso.
            }
            return false; // Agendamento não encontrado.
        }

        /// <summary>
        /// Obtém a lista de todos os agendamentos.
        /// </summary>
        /// <returns>Lista de agendamentos de manutenção.</returns>
        public List<AgendamentoManutencao> ObterAgendamentos()
        {
            return agendamentos;
        }

        #endregion
    }
}
