﻿/**
 * @file VeiculoManager.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Gerenciador de veículos, responsável por operações como adicionar, atualizar e remover veículos.
 * @version 0.1
 * @date 2023-12-17
 * @copyright Copyright (c) 2023
 */

using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    /// <summary>
    /// Gerencia as operações relacionadas a veículos, como adicionar, atualizar e remover.
    /// </summary>
    public class VeiculoManager
    {
        #region Propriedades
        private List<Veiculo> veiculos;
        #endregion

        #region Construtores
        public VeiculoManager()
        {
            veiculos = new List<Veiculo>();
        }
        #endregion

        #region Métodos

        /// <summary>
        /// Adiciona um veículo à lista de veículos.
        /// </summary>
        /// <param name="veiculo">Veículo a ser adicionado.</param>
        /// <returns>True indica que o veículo foi adicionado com sucesso.</returns>
        public bool AdicionarVeiculo(Veiculo veiculo)
        {
            veiculos.Add(veiculo);
            return true; // Veículo adicionado com sucesso
        }

        /// <summary>
        /// Atualiza as informações de um veículo existente.
        /// </summary>
        /// <param name="id">ID do veículo a ser atualizado.</param>
        /// <param name="veiculoAtualizado">Dados atualizados do veículo.</param>
        /// <returns>True indica que o veículo foi atualizado com sucesso.</returns>
        public bool AtualizarVeiculo(int id, Veiculo veiculoAtualizado)
        {
            var veiculo = ObterVeiculoPorId(id);
            veiculo.Modelo = veiculoAtualizado.Modelo;
            veiculo.Marca = veiculoAtualizado.Marca;
            // Outras atualizações de propriedades conforme necessário
            return true; // Veículo atualizado com sucesso
        }

        /// <summary>
        /// Remove um veículo da lista pelo seu ID.
        /// </summary>
        /// <param name="id">ID do veículo a ser removido.</param>
        /// <returns>True indica que o veículo foi removido com sucesso.</returns>
        public bool RemoverVeiculo(int id)
        {
            var veiculo = ObterVeiculoPorId(id);
            veiculos.Remove(veiculo);
            return true; // Veículo removido com sucesso
        }

        /// <summary>
        /// Lista todos os veículos.
        /// </summary>
        /// <returns>Lista de veículos.</returns>
        public List<Veiculo> ListarVeiculos()
        {
            return veiculos;
        }

        /// <summary>
        /// Obtém um veículo pelo seu ID.
        /// Lança uma exceção se o veículo não for encontrado.
        /// </summary>
        /// <param name="id">ID do veículo.</param>
        /// <returns>O veículo correspondente ao ID fornecido.</returns>
        public Veiculo ObterVeiculoPorId(int id)
        {
            var veiculo = veiculos.FirstOrDefault(v => v.ID == id);
            if (veiculo == null)
            {
                throw new ArgumentException("Veículo não encontrado.");
            }
            return veiculo;
        }

        #endregion
    }
}
