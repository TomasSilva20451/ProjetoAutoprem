﻿/**
 * @file MockVeiculo.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe MockVeiculo para testes, derivada da classe Veiculo
 * @version 0.1
 * @date 2023-12-17
 * @copyright Copyright (c) 2023
 */

using System;

namespace AutoPrem.Core
{
    /// <summary>
    /// Classe MockVeiculo usada para simular operações em um veículo para fins de teste.
    /// Herda da classe base Veiculo e implementa as operações de manutenção e substituição.
    /// </summary>
    public class MockVeiculo : Veiculo
    {
        #region Construtores

        /// <summary>
        /// Construtor para inicializar um MockVeiculo.
        /// </summary>
        /// <param name="id">Identificador do veículo.</param>
        /// <param name="modelo">Modelo do veículo.</param>
        /// <param name="marca">Marca do veículo.</param>
        /// <param name="ano">Ano de fabricação do veículo.</param>
        public MockVeiculo(int id, string modelo, string marca, int ano) : base(id, modelo, marca, ano)
        {
            // Inicialização concreta, se necessário
        }

        #endregion

        #region Métodos Overrides

        /// <summary>
        /// Realiza a manutenção do veículo. Esta implementação é para fins de teste.
        /// </summary>
        /// <returns>True indica que a manutenção foi "realizada" com sucesso (simulada).</returns>
        public override bool RealizarManutencao()
        {
            // Implementação concreta para fins de teste
            return true; // Implementação de exemplo, sempre bem-sucedida
        }

        /// <summary>
        /// Substitui o veículo. Esta implementação é para fins de teste.
        /// </summary>
        /// <returns>True indica que a substituição foi "realizada" com sucesso (simulada).</returns>
        public override bool Substituir()
        {
            // Implementação concreta para fins de teste
            return true; // Implementação de exemplo, sempre bem-sucedida
        }

        #endregion
    }
}
