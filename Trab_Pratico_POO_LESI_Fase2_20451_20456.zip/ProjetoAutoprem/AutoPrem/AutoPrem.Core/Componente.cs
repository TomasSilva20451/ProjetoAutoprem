﻿/**
 * @file Componente.cs
 * @author Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Definição da classe abstrata Componente
 * @version 0.2
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */

/// <summary>
/// Classe abstrata que define a estrutura e o comportamento básico de um componente.
/// </summary>
public abstract class Componente
{
    #region Propriedades
    /// <summary>
    /// Identificador único do componente.
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    /// Descrição do componente.
    /// </summary>
    public string? Descricao { get; set; }

    /// <summary>
    /// Indica se a manutenção foi realizada.
    /// </summary>
    public bool Realizado { get; set; }

    /// <summary>
    /// Indica se o componente está danificado.
    /// </summary>
    public bool EstaDanificado { get; set; }
    #endregion

    #region Métodos Abstratos

    /// <summary>
    /// Realiza a manutenção do componente.
    /// </summary>
    /// <returns>
    /// Retorna true se a manutenção foi realizada com sucesso, 
    /// false caso contrário (por exemplo, se o componente não puder ser reparado).
    /// </returns>
    public abstract bool RealizarManutencao();

    /// <summary>
    /// Substitui o componente por um novo.
    /// </summary>
    /// <returns>
    /// Retorna true se a substituição foi realizada com sucesso, 
    /// false caso contrário (por exemplo, se a substituição não for possível devido à falta de peças).
    /// </returns>
    public abstract bool Substituir();

    #endregion

    #region Outros Métodos e Propriedades

    // Adicione mais métodos e propriedades conforme necessário

    #endregion
}
