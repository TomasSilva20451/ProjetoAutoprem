﻿/**
 * @file Cliente.cs
 * @authors Tomás (a20451@alunos.ipca.pt) e Telmo (a20456@alunos.ipca.pt)
 * @brief Classe que representa um cliente
 * @version 0.1
 * @date 2023-12-30
 * @remarks ADOÇÃO ADEQUADA DAS NORMAS CLS; DOCUMENTAÇÃO ADEQUADA DO CÓDIGO; ESTRUTURA DE PASTAS, NOMES E TIPOS DOS PROJETOS, NOMES DE MÉTODOS E CLASSES, NOME DO FICHEIRO A SUBMETER
 */

using System;

namespace AutoPrem.Core
{
    /// <summary>
    /// Classe representando um cliente.
    /// </summary>
    public class Cliente
    {
        #region Propriedades
        /// <summary>
        /// Nome do cliente.
        /// </summary>
        public string? Nome { get; set; }

        /// <summary>
        /// Endereço de email do cliente.
        /// </summary>
        public string? Email { get; set; }

        /// <summary>
        /// Número de telefone do cliente.
        /// </summary>
        public string? NumeroTelefone { get; set; }

        /// <summary>
        /// Detalhes de pagamento do cliente.
        /// </summary>
        public string? DetalhesPagamento { get; set; }
        #endregion

        #region Construtores
        /// <summary>
        /// Construtor padrão sem parâmetros.
        /// </summary>
        public Cliente()
        {
        }

        /// <summary>
        /// Construtor que aceita nome e email do cliente.
        /// </summary>
        /// <param name="nome">Nome do cliente.</param>
        /// <param name="email">Endereço de email do cliente.</param>
        public Cliente(string nome, string email)
        {
            Nome = nome;
            Email = email;
        }
        #endregion

        #region Outros Métodos
        // Adicione mais métodos conforme necessário
        #endregion
    }
}
