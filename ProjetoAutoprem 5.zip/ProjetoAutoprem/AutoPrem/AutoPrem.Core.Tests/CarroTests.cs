﻿/**
 * @file CarroTests.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Testes para a classe Carro
 * @version 0.1
 * @date 2023-12-18
 * @copyright Copyright (c) 2023
 */

using Microsoft.VisualStudio.TestTools.UnitTesting;
using AutoPrem.Core;

[TestClass]
public class CarroTests
{
    #region Métodos de Teste

    [TestMethod]
    public void TestLigarCarro()
    {
        // Arrange
        Carro carro = new Carro(1);

        // Act
        carro.Ligar();

        // Assert
        Assert.IsTrue(carro.EstaEmManutencao);
    }

    [TestMethod]
    public void TestDesligarCarro()
    {
        // Arrange
        Carro carro = new Carro(1);

        // Act
        carro.Desligar();

        // Assert
        Assert.IsFalse(carro.EstaEmManutencao);
    }

    [TestMethod]
    public void TestRealizarManutencaoCarro()
    {
        // Arrange
        Carro carro = new Carro(1);

        // Act
        bool result = carro.RealizarManutencaoCarro();

        // Assert
        Assert.IsTrue(result);
        Assert.IsTrue(carro.EstaEmManutencao);
    }

    // Adicione mais testes conforme necessário

    #endregion
}