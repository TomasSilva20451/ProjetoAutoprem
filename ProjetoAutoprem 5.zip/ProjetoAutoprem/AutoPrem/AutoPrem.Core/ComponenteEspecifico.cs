﻿/**
 * @file ComponenteEspecifico.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Definition of the ComponenteEspecifico class, derived from Componente
 * @version 0.1
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */

public class ComponenteEspecifico : Componente
{
    #region Propriedades Adicionadas

    public bool ManutencaoRealizada { get; private set; }
    public bool SubstituicaoRealizada { get; private set; }
    public bool LimparRealizada { get; private set; }
    public bool LubrificarRealizada { get; private set; }
    public bool RemoverRealizada { get; private set; }
    public bool InstalarRealizada { get; private set; }
    #endregion

    #region Métodos Overrides

    /// <summary>
    /// Realiza a manutenção específica do componente.
    /// </summary>
    public override void RealizarManutencao()
    {
        // Verifica se o componente está danificado
        if (EstaDanificado)
        {
            // Substitui o componente por um novo
            Substituir();
        }
        else
        {
            // Limpa e lubrifica o componente
            Limpar();
            Lubrificar();
        }

        ManutencaoRealizada = true;
    }

    /// <summary>
    /// Substitui o componente específico por um novo.
    /// </summary>
    public override void Substituir()
    {
        // Remove o componente antigo
        Remover();

        // Instala o componente novo
        Instalar();

        SubstituicaoRealizada = true;
    }

    #endregion

    #region Métodos Privados

    private void Limpar()
    {
        // Lógica para limpar o componente 
        // Por exemplo, podemos definir a propriedade "LimparRealizada" como true para simular a remoção
        LimparRealizada = true;
    }


    private void Lubrificar()
    {
        // Lógica para lubrificar o componente 
        // Por exemplo, podemos definir a propriedade "LubrificarRealizada" como true para simular a remoção
        LubrificarRealizada = true;
    }

    private void Remover()
    {
        // Console.WriteLine("Removendo o componente antigo...");
        // Lógica para remover o componente antigo
        // Por exemplo, podemos definir a propriedade "EstaDanificado" como true para simular a remoção
        EstaDanificado = true;
    }

    private void Instalar()
    {
        // Verifique se o componente antigo foi removido
        if (!RemoverRealizada)
        {
            throw new Exception("O componente antigo deve ser removido antes de instalar o novo.");
        }

        // Instale o componente novo
        // Use ferramentas adequadas para o tipo de componente

        // Conecte quaisquer componentes ou acessórios associados ao componente novo

        // Aperte todos os parafusos e porcas de acordo com as especificações

        InstalarRealizada = true;
    }

    #endregion

    #region Outros Métodos e Propriedades

    // Adicione mais métodos e propriedades conforme necessário

    #endregion
}
