﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using AutoPrem.Core;

[TestClass]
public class ComponenteTests
{
    [TestMethod]
    public void RealizarManutencao_ComponenteGenerico_LogicaDeManutencaoGenerico()
    {
        // Arrange
        Componente componente = new ComponenteGenerico();

        // Act
        componente.RealizarManutencao();

        // Assert
        Assert.IsTrue(((ComponenteGenerico)componente).ManutencaoRealizada);
    }

    [TestMethod]
    public void Substituir_ComponenteGenerico_LogicaDeSubstituicaoGenerico()
    {
        // Arrange
        Componente componente = new ComponenteGenerico();

        // Act
        componente.Substituir();

        // Assert
        Assert.IsTrue(((ComponenteGenerico)componente).SubstituicaoRealizada);
    }

    private class ComponenteGenerico : Componente
    {
        public bool ManutencaoRealizada { get; private set; }
        public bool SubstituicaoRealizada { get; private set; }

        public override void RealizarManutencao()
        {
            // Lógica de manutenção genérica
            ManutencaoRealizada = true;
        }

        public override void Substituir()
        {
            // Lógica de substituição genérica
            SubstituicaoRealizada = true;
        }
    }
}
