﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using AutoPrem.Core;

[TestClass]
public class VeiculoTests
{
    [TestMethod]
    public void TestLigarVeiculo()
    {
        // Arrange
        Veiculo veiculo = new Carro(1);

        // Act
        veiculo.Ligar();

        // Assert
        Assert.IsTrue(veiculo.EstaEmManutencao);
    }
}
