﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using AutoPrem.Core;

[TestClass]
public class CarroTests
{
    [TestMethod]
    public void TestLigarCarro()
    {
        // Arrange
        Carro carro = new Carro(1);

        // Act
        carro.Ligar();

        // Assert
        Assert.IsTrue(carro.EstaEmManutencao);
    }

    [TestMethod]
    public void TestDesligarCarro()
    {
        // Arrange
        Carro carro = new Carro(1);

        // Act
        carro.Desligar();

        // Assert
        Assert.IsFalse(carro.EstaEmManutencao);
    }

    [TestMethod]
    public void TestRealizarManutencaoCarro()
    {
        // Arrange
        Carro carro = new Carro(1);

        // Act
        bool result = carro.RealizarManutencaoCarro();

        // Assert
        Assert.IsTrue(result);
        Assert.IsTrue(carro.EstaEmManutencao);
    }
}
