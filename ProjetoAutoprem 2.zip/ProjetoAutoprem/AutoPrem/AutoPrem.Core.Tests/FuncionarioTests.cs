﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using AutoPrem.Core;

[TestClass]
public class FuncionarioTests
{
    [TestMethod]
    public void RealizarTarefa_TarefaBemSucedida_RetornaTrue()
    {
        // Arrange
        Funcionario funcionario = new Funcionario("João");
        ComponenteEspecifico componente = new ComponenteEspecifico();

        // Act
        bool resultado = funcionario.RealizarTarefa(componente);

        // Assert
        Assert.IsTrue(resultado);
    }

    [TestMethod]
    public void RealizarTarefa_TarefaFalhada_RetornaFalse()
    {
        // Arrange
        Funcionario funcionario = new Funcionario("Maria");
        ComponenteEspecifico componente = new ComponenteEspecifico();
        // Forçar falha na tarefa definindo um componente em um estado específico
        componente.RealizarManutencao(); // Simulando falha

        // Act
        bool resultado = funcionario.RealizarTarefa(componente);

        // Assert
        Assert.IsFalse(resultado);
    }

    // Adicione mais testes conforme necessário
}
