﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using AutoPrem.Core;

[TestClass]
public class ComponenteEspecificoTests
{
    [TestMethod]
    public void RealizarManutencao_ComponenteEspecifico_LogicaDeManutencaoEspecifica()
    {
        // Arrange
        ComponenteEspecifico componente = new ComponenteEspecifico();

        // Act
        componente.RealizarManutencao();

        // Assert
        Assert.IsTrue(componente.ManutencaoRealizada);
    }

    // Adicione mais testes conforme necessário
}
