﻿using AutoPrem.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

[TestClass]
public class VendaVeiculoServiceTests
{
    [TestMethod]
    public void AdicionarVeiculoParaVenda_DeveAdicionarVeiculoParaVenda()
    {
        // Arrange
        var vendaVeiculoService = new VendaVeiculoService();
        var veiculo = new Veiculo(1, "Marca", "Modelo", 2023);

        // Act
        vendaVeiculoService.AdicionarVeiculoParaVenda(veiculo);

        // Assert
        var veiculosDisponiveis = vendaVeiculoService.ListarVeiculosDisponiveis();
        Assert.IsTrue(veiculosDisponiveis.Contains(veiculo));
    }

    [TestMethod]
    public void RealizarVenda_VeiculoDisponivel_DeveRealizarVenda()
    {
        // Arrange
        var vendaVeiculoService = new VendaVeiculoService();
        var veiculo = new Veiculo(1, "Marca", "Modelo", 2023);
        var cliente = new Cliente("NomeCliente", "EmailCliente");
        vendaVeiculoService.AdicionarVeiculoParaVenda(veiculo);

        // Act
        vendaVeiculoService.RealizarVenda(veiculo.ID, cliente);

        // Assert
        var vendasRealizadas = vendaVeiculoService.ObterRegistroVendas();
        Assert.AreEqual(1, vendasRealizadas.Count); // Check if one sale is recorded
        var vendaRegistrada = vendasRealizadas[0];
        Assert.AreEqual(cliente, vendaRegistrada.Cliente); // Check if the client matches
        Assert.AreEqual(veiculo, vendaRegistrada.Veiculo); // Check if the vehicle matches
        Assert.IsFalse(vendaVeiculoService.ListarVeiculosDisponiveis().Contains(veiculo)); // Check if the vehicle is no longer available for sale
    }

    [TestMethod]
    public void RealizarVenda_VeiculoNaoDisponivel_NaoDeveRealizarVenda()
    {
        // Arrange
        var vendaVeiculoService = new VendaVeiculoService();
        var veiculo = new Veiculo(1, "Marca", "Modelo", 2023);
        var cliente = new Cliente("NomeCliente", "EmailCliente");

        // Act
        vendaVeiculoService.RealizarVenda(veiculo.ID, cliente);

        // Assert
        var vendasRealizadas = vendaVeiculoService.ObterRegistroVendas();
        Assert.AreEqual(0, vendasRealizadas.Count); // Check if no sale is recorded
    }
}
