﻿using AutoPrem.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

[TestClass]
public class AgendamentoServiceTests
{
    [TestMethod]
    public void AgendarManutencao_DeveAgendarManutencao()
    {
        // Arrange
        var agendamentoService = new AgendamentoService();
        var dataAgendamento = DateTime.Now.AddDays(7);
        var veiculo = new Veiculo(1, "Marca", "Modelo", 2024); 
        var descricao = "Descrição da manutenção";

        // Act
        agendamentoService.AgendarManutencao(dataAgendamento, veiculo, descricao);

        // Assert
        var agendamentos = agendamentoService.ObterAgendamentos();
        Assert.AreEqual(1, agendamentos.Count);
        var agendamento = agendamentos[0];
        Assert.AreEqual(dataAgendamento, agendamento.DataAgendamento);
        Assert.AreEqual(veiculo, agendamento.Veiculo);
        Assert.AreEqual(descricao, agendamento.Descricao);
    }

    [TestMethod]
    public void AtualizarAgendamento_AgendamentoExistente_DeveAtualizar()
    {
        // Arrange
        var agendamentoService = new AgendamentoService();
        var dataAgendamento = DateTime.Now.AddDays(7);
        var veiculo = new Veiculo(1, "Marca", "Modelo", 2024); 
        var descricao = "Descrição da manutenção";
        agendamentoService.AgendarManutencao(dataAgendamento, veiculo, descricao);

        // Act
        var novoDataAgendamento = DateTime.Now.AddDays(14);
        var novaDescricao = "Nova descrição da manutenção";
        agendamentoService.AtualizarAgendamento(1, novoDataAgendamento, novaDescricao);

        // Assert
        var agendamentos = agendamentoService.ObterAgendamentos();
        Assert.AreEqual(1, agendamentos.Count);
        var agendamentoAtualizado = agendamentos[0];
        Assert.AreEqual(novoDataAgendamento, agendamentoAtualizado.DataAgendamento);
        Assert.AreEqual(novaDescricao, agendamentoAtualizado.Descricao);
    }

    [TestMethod]
    public void CancelarAgendamento_AgendamentoExistente_DeveCancelar()
    {
        // Arrange
        var agendamentoService = new AgendamentoService();
        var dataAgendamento = DateTime.Now.AddDays(7);
        var veiculo = new Veiculo(1, "Marca", "Modelo", 2024); 
        var descricao = "Descrição da manutenção";
        agendamentoService.AgendarManutencao(dataAgendamento, veiculo, descricao);

        // Act
        agendamentoService.CancelarAgendamento(1);

        // Assert
        var agendamentos = agendamentoService.ObterAgendamentos();
        Assert.AreEqual(0, agendamentos.Count);
    }
}
