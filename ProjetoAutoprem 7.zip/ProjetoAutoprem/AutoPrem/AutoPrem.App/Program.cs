﻿/**
 * @file Program.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Ponto de entrada principal para a aplicação
 * @version 0.2
 * @date 2023-12-18
 * @copyright Copyright (c) 2023
 */

using System;
using AutoPrem.Core;
using AutoPrem.Core.Services;

class Program
{
    #region Variaveis
    private readonly IIOService ioService;
    #endregion

    #region Construtores
    /// <summary>
    /// Inicializa uma nova instância da classe <see cref='Program'/>.
    /// </summary>
    /// <param name="ioService">The IO service.</param>
    public Program(IIOService ioService)
    {
        this.ioService = ioService;
    }
    #endregion

    #region Metodo Principal
    /// <summary>
    /// O ponto de entrada principal para a aplicação.
    /// </summary>
    static void Main()
    {
        Program program = new Program(new ConsoleIOService());
        program.Run();
    }
    #endregion

    #region Metodos Publicos
    /// <summary>
    /// Executa esta instância.
    /// </summary>
    public void Run()
    {
        ExemploUtilizacao();
        ExemploServicosTarefas();
    }
    #endregion

    #region Metodos Privados
    /// <summary>
    /// Exemplo de utilização das classes e serviços implementados.
    /// </summary>
    private void ExemploUtilizacao()
    {
        Veiculo veiculo = new Carro(1);
        Carro carro = new Carro(2);
        Moto moto = new Moto(3);

        LidarComVeiculoException(() => veiculo.Ligar(), $"Veículo {veiculo.ID} ligado com sucesso.");
        LidarComVeiculoException(() => carro.Ligar(), $"Carro {carro.ID} ligado com sucesso.");
        LidarComVeiculoException(() => moto.Ligar(), $"Moto {moto.ID} ligada com sucesso.");

        LidarComVeiculoException(() => veiculo.Desligar(), $"Veículo {veiculo.ID} desligado com sucesso.");
        LidarComVeiculoException(() => carro.Desligar(), $"Carro {carro.ID} desligado com sucesso.");
        LidarComVeiculoException(() => moto.Desligar(), $"Moto {moto.ID} desligada com sucesso.");
    }

    /// <summary>
    /// Lidar com exceções ao executar a ação relacionada ao veículo.
    /// </summary>
    /// <param name="action">Ação a ser executada.</param>
    /// <param name="sucessoMessage">Mensagem de sucesso a ser exibida.</param>
    private void LidarComVeiculoException(Action action, string sucessoMessage)
    {
        try
        {
            action.Invoke();
            ioService.WriteLine(sucessoMessage);
        }
        catch (Exception ex)
        {
            ioService.WriteLine($"Erro: {ex.Message}");
        }
    }

    /// <summary>
    /// Exemplo de utilização de serviços e tarefas.
    /// </summary>
    private void ExemploServicosTarefas()
    {
        // Serviço de Manutenção
        try
        {
            ServicoManutencao servico = new ServicoManutencao(DateTime.Now, "Manutenção de rotina", new ComponenteEspecifico());
            servico.RealizarManutencao(new ComponenteEspecifico());
            ioService.WriteLine("Manutenção realizada com sucesso.");
        }
        catch (Exception ex)
        {
            ioService.WriteLine($"Erro ao realizar manutenção: {ex.Message}");
        }

        // Tarefa do Funcionário
        try
        {
            Funcionario funcionario = new Funcionario("João");
            bool sucessoTarefa = funcionario.RealizarTarefa(new ComponenteEspecifico());
            ioService.WriteLine(sucessoTarefa ? "Tarefa realizada com sucesso." : "Erro ao realizar tarefa.");
        }
        catch (Exception ex)
        {
            ioService.WriteLine($"Erro ao realizar tarefa: {ex.Message}");
        }
    }

    #endregion
}
