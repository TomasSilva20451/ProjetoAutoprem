﻿/**
* @file AgendamentoManutencao.cs
* @author Tomás (a20451@alunos.ipca.pt)
* @author Telmo (a20456@alunos.ipca.pt)
* @brief Classe que representa um agendamento de manutenção
* @version 0.1
* @date 2023-12-22
* 
* @copyright Copyright (c) 2023
* 
*/

using System;

namespace AutoPrem.Core
{

    #region AgendamentoManutencao

    /// <summary>
    /// Classe que representa um agendamento de manutenção.
    /// </summary>
    public class AgendamentoManutencao
    {

        /// <summary>
        /// Data de agendamento da manutenção.
        /// </summary>
        public DateTime DataAgendamento { get; set; }

        /// <summary>
        /// Descrição da manutenção.
        /// </summary>
        public string Descricao { get; set; } = "Manutenção de rotina";

        /// <summary>
        /// Componente a ser mantido.
        /// </summary>
        public Componente Componente { get; set; } = new ComponenteEspecifico();

        #endregion

    }

}
