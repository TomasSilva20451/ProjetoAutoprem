﻿/**
 * @file ServicoManutencao.cs
 * @author Tomás (a20451@alunos.ipca.pt)
 * @author Telmo (a20456@alunos.ipca.pt)
 * @brief Definition of the ServicoManutencao class
 * @version 0.2
 * @date 2023-12-12
 * @copyright Copyright (c) 2023
 */

using System;
using AutoPrem.Core;

public class ServicoManutencao
{
    #region Propriedades

    /// <summary>
    /// Data de agendamento do serviço de manutenção.
    /// </summary>
    public DateTime DataAgendamento { get; }

    /// <summary>
    /// Nome do serviço de manutenção.
    /// </summary>
    public string? Nome { get; set; }

    /// <summary>
    /// Descrição do serviço de manutenção.
    /// </summary>
    public string Descricao { get; private set; }

    /// <summary>
    /// Indica se o serviço de manutenção foi realizado.
    /// </summary>
    public bool Realizado { get; set; }

    /// <summary>
    /// Classe Componente
    /// </summary>
    public Componente Componente { get; set; }

    /// <summary>
    /// Classe AgendamentoManutencao
    /// </summary>
    public AgendamentoManutencao? Agendamento { get; set; }

    #endregion

    #region Construtores

    /// <summary>
    /// Construtor da classe ServicoManutencao.
    /// </summary>
    public ServicoManutencao(DateTime dataAgendamento, string descricao, Componente componente)
    {
        DataAgendamento = dataAgendamento;
        Descricao = descricao;
        Componente = componente;
        Realizado = false;
    }


    #endregion

    #region Métodos

    /// <summary>
    /// Realiza a manutenção utilizando um componente específico.
    /// </summary>
    /// <param name="componente">Componente a ser mantido.</param>
    public void RealizarManutencao(Componente componente)
    {
        componente.RealizarManutencao();

        // Se a manutenção foi realizada com sucesso, defina o serviço de manutenção como realizado
        if (componente.Realizado)
        {
            Realizado = true;
        }
    }

    public void Executar()
    {
        
        Console.WriteLine($"Executando serviço de manutenção: {Nome}");
    }

    public AgendamentoManutencao AgendarManutencao()
    {
        // Cria um novo agendamento de manutenção
        AgendamentoManutencao agendamento = new AgendamentoManutencao();
        agendamento.DataAgendamento = DataAgendamento;
        agendamento.Descricao = Descricao;
        agendamento.Componente = Componente;

        // Armazena o agendamento
        Agendamento = agendamento;

        // Imprime uma mensagem de confirmação
        Console.WriteLine($"Agendando serviço de manutenção para {agendamento.DataAgendamento.ToShortDateString()}: {agendamento.Descricao}");

        // Marca a manutenção como realizada
        Realizado = true;

        return agendamento;
    }
    #endregion
}