﻿using System;
namespace AutoPrem.Core
{
    public class Cliente
    {
        public string? Nome { get; set; }
        public string? Email { get; set; }
        public string? NumeroTelefone { get; set; }
        public string? DetalhesPagamento { get; set; }

        // Adicione mais informações conforme necessário
    }

}

