﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    public class VeiculoManager
    {
        private List<Veiculo> veiculos;

        public VeiculoManager()
        {
            veiculos = new List<Veiculo>();
        }

        public void AdicionarVeiculo(Veiculo veiculo)
        {
            veiculos.Add(veiculo);
            Console.WriteLine("Veículo adicionado com sucesso.");
        }

        public Veiculo ObterVeiculoPorId(int id)
        {
            return veiculos.FirstOrDefault(v => v.ID == id) ?? throw new ArgumentException("Veículo não encontrado.");
        }

        public List<Veiculo> ListarVeiculos()
        {
            return veiculos;
        }

        public void AtualizarVeiculo(int id, Veiculo veiculoAtualizado)
        {
            var veiculo = ObterVeiculoPorId(id);
            // Agora temos certeza de que veiculo não é nulo
            // Atualize as propriedades do veículo conforme necessário
            veiculo.Modelo = veiculoAtualizado.Modelo;
            veiculo.Marca = veiculoAtualizado.Marca;
            // Outras propriedades...
            Console.WriteLine("Veículo atualizado com sucesso.");
        }

        public void RemoverVeiculo(int id)
        {
            var veiculo = ObterVeiculoPorId(id);
            // Agora temos certeza de que veiculo não é nulo
            veiculos.Remove(veiculo);
            Console.WriteLine("Veículo removido com sucesso.");
        }
    }
}
