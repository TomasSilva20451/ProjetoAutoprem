﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AutoPrem.Core
{
    public class PecaManager
    {
        private List<Componente> pecas;

        public PecaManager()
        {
            pecas = new List<Componente>();
        }

        // Método para adicionar uma peça
        public void AdicionarPeca(Componente peca)
        {
            pecas.Add(peca);
            Console.WriteLine("Peça adicionada com sucesso.");
        }

        // Método para listar todas as peças
        public List<Componente> ListarPecas()
        {
            return pecas;
        }

        // Método para obter uma peça por ID
        public Componente? ObterPecaPorId(int id)
        {
            return pecas.FirstOrDefault(p => p.Id == id);
        }

        // Método para atualizar uma peça por ID
        public void AtualizarPeca(int id, Componente pecaAtualizada)
        {
            var peca = ObterPecaPorId(id);
            if (peca != null)
            {
                // Atualize as propriedades da peça conforme necessário
                // Exemplo: peca.Nome = pecaAtualizada.Nome;
                Console.WriteLine("Peça atualizada com sucesso.");
            }
            else
            {
                Console.WriteLine("Peça não encontrada.");
            }
        }

        // Método para remover uma peça por ID
        public void RemoverPeca(int id)
        {
            var peca = ObterPecaPorId(id);
            if (peca != null)
            {
                pecas.Remove(peca);
                Console.WriteLine("Peça removida com sucesso.");
            }
            else
            {
                Console.WriteLine("Peça não encontrada.");
            }
        }
    }
}
